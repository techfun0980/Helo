import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Radio, c as Pause, d as Car, f as Bluetooth, i as Speaker, l as Headphones, o as Plus, r as Trash2, s as Play, t as X, u as Copy } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-k9NWu8gC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BANDS = [
	{
		hz: 31,
		label: "31"
	},
	{
		hz: 62,
		label: "62"
	},
	{
		hz: 125,
		label: "125"
	},
	{
		hz: 250,
		label: "250"
	},
	{
		hz: 500,
		label: "500"
	},
	{
		hz: 1e3,
		label: "1k"
	},
	{
		hz: 2e3,
		label: "2k"
	},
	{
		hz: 4e3,
		label: "4k"
	},
	{
		hz: 8e3,
		label: "8k"
	},
	{
		hz: 16e3,
		label: "16k"
	}
];
var BAND_COUNT = BANDS.length;
var FLAT$1 = [
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0
];
var PRESETS = [
	{
		id: "flat",
		name: "Flat",
		hint: "No color",
		gains: [...FLAT$1]
	},
	{
		id: "bass",
		name: "Bass",
		hint: "Low lift",
		gains: [
			7,
			6,
			4,
			2,
			0,
			0,
			0,
			0,
			0,
			0
		]
	},
	{
		id: "treble",
		name: "Treble",
		hint: "Air and detail",
		gains: [
			0,
			0,
			0,
			0,
			0,
			0,
			1,
			3,
			5,
			6
		]
	},
	{
		id: "vocal",
		name: "Vocal",
		hint: "Presence for voices",
		gains: [
			-2,
			-1,
			0,
			1,
			3,
			4,
			4,
			2,
			0,
			-1
		]
	},
	{
		id: "podcast",
		name: "Podcast",
		hint: "Speech clarity",
		gains: [
			-4,
			-2,
			0,
			2,
			4,
			4,
			2,
			1,
			-1,
			-2
		]
	},
	{
		id: "earbud",
		name: "Earbud",
		hint: "Seal-friendly bass",
		gains: [
			3,
			4,
			3,
			1,
			0,
			1,
			2,
			1,
			-1,
			-2
		]
	},
	{
		id: "speaker",
		name: "Speaker",
		hint: "Small-speaker fill",
		gains: [
			5,
			4,
			2,
			1,
			0,
			0,
			1,
			2,
			2,
			1
		]
	},
	{
		id: "harman",
		name: "Harman",
		hint: "Headphone target",
		gains: [
			5,
			4,
			2,
			1,
			0,
			0,
			1,
			2,
			3,
			2
		]
	},
	{
		id: "rock",
		name: "Rock",
		hint: "Scoop and bite",
		gains: [
			4,
			3,
			2,
			0,
			-1,
			-1,
			1,
			3,
			4,
			4
		]
	},
	{
		id: "hiphop",
		name: "Hip-hop",
		hint: "Weight and snap",
		gains: [
			6,
			5,
			3,
			1,
			-1,
			0,
			1,
			2,
			3,
			3
		]
	},
	{
		id: "electronic",
		name: "Electronic",
		hint: "Sub and sparkle",
		gains: [
			6,
			4,
			1,
			0,
			-1,
			0,
			1,
			2,
			4,
			5
		]
	},
	{
		id: "jazz",
		name: "Jazz",
		hint: "Warm and open",
		gains: [
			3,
			2,
			1,
			1,
			-1,
			-1,
			0,
			1,
			2,
			3
		]
	},
	{
		id: "classical",
		name: "Classical",
		hint: "Natural hall",
		gains: [
			3,
			2,
			1,
			0,
			0,
			0,
			0,
			1,
			2,
			3
		]
	},
	{
		id: "acoustic",
		name: "Acoustic",
		hint: "String body",
		gains: [
			2,
			2,
			1,
			0,
			1,
			2,
			2,
			1,
			1,
			1
		]
	},
	{
		id: "night",
		name: "Night",
		hint: "Softer highs",
		gains: [
			1,
			2,
			1,
			0,
			0,
			-1,
			-2,
			-4,
			-6,
			-7
		]
	},
	{
		id: "workout",
		name: "Workout",
		hint: "Energy curve",
		gains: [
			5,
			4,
			2,
			0,
			-1,
			0,
			2,
			3,
			4,
			3
		]
	},
	{
		id: "cinema",
		name: "Cinema",
		hint: "Soundbar weight",
		gains: [
			5,
			4,
			2,
			0,
			-1,
			0,
			1,
			2,
			3,
			2
		]
	},
	{
		id: "car",
		name: "Car",
		hint: "Road-noise cut",
		gains: [
			2,
			3,
			1,
			-1,
			-2,
			1,
			3,
			3,
			2,
			1
		]
	}
];
var SOURCES$1 = [
	{
		id: "pulse",
		label: "Pulse"
	},
	{
		id: "ambient",
		label: "Ambient"
	},
	{
		id: "voice",
		label: "Voice"
	},
	{
		id: "noise",
		label: "Noise"
	},
	{
		id: "file",
		label: "File"
	},
	{
		id: "mic",
		label: "Mic"
	}
];
var KIND_OPTIONS = [
	{
		id: "earbud",
		label: "Earbuds"
	},
	{
		id: "headphone",
		label: "Headphones"
	},
	{
		id: "speaker",
		label: "Speaker"
	},
	{
		id: "soundbar",
		label: "Soundbar"
	},
	{
		id: "car",
		label: "Car"
	}
];
var GROUPS = {
	bass: [
		0,
		1,
		2
	],
	mid: [
		3,
		4,
		5,
		6
	],
	treble: [
		7,
		8,
		9
	]
};
function clampDb(n) {
	const rounded = Math.round(n * 10) / 10;
	return Math.max(-12, Math.min(12, rounded));
}
function formatDb(n) {
	const v = Math.round(n * 10) / 10;
	if (Math.abs(v) < .05) return "0.0";
	return `${v > 0 ? "+" : ""}${v.toFixed(1)}`;
}
function formatBalance(n) {
	if (Math.abs(n) < .03) return "Center";
	const pct = Math.round(Math.abs(n) * 100);
	return n < 0 ? `Left ${pct}` : `Right ${pct}`;
}
function liveGains(device) {
	return device.ab === "a" ? device.gains : device.altGains;
}
function groupIndexes(group) {
	return GROUPS[group];
}
function groupAverage(gains, group) {
	const idx = GROUPS[group];
	return idx.reduce((total, i) => total + (gains[i] ?? 0), 0) / idx.length;
}
function sameCurve(a, b) {
	if (a.length !== b.length) return false;
	return a.every((value, index) => Math.abs(value - (b[index] ?? 0)) < .05);
}
function presetById(id) {
	return PRESETS.find((preset) => preset.id === id);
}
function defaultPresetFor(kind) {
	if (kind === "earbud") return presetById("earbud") ?? PRESETS[0];
	if (kind === "headphone") return presetById("harman") ?? PRESETS[0];
	if (kind === "soundbar") return presetById("cinema") ?? PRESETS[0];
	if (kind === "car") return presetById("car") ?? PRESETS[0];
	return presetById("speaker") ?? PRESETS[0];
}
function identifyCurve(gains, custom) {
	const built = PRESETS.find((preset) => sameCurve(preset.gains, gains));
	if (built) return {
		id: built.id,
		name: built.name
	};
	const saved = custom.find((preset) => sameCurve(preset.gains, gains));
	if (saved) return {
		id: saved.id,
		name: saved.name
	};
	return {
		id: "custom",
		name: "Custom"
	};
}
function kindLabel(kind) {
	return KIND_OPTIONS.find((option) => option.id === kind)?.label ?? "Speaker";
}
function originLabel(origin) {
	if (origin === "demo") return "Starter";
	if (origin === "system") return "System output";
	if (origin === "bluetooth") return "Bluetooth";
	return "Saved";
}
function guessKind(name) {
	const n = name.toLowerCase();
	if (/airpod|buds|earbud|nothing ear|wf-|liberty|pixel bud|jabra elite/.test(n)) return "earbud";
	if (/car|vehicle|auto|honda|toyota|bmw|tesla|hyundai|kia|ford/.test(n)) return "car";
	if (/soundbar|sound bar|arc |beam|playbar|sonos arc/.test(n)) return "soundbar";
	if (/headphone|headset|wh-|qc\d|momentum|hd 6|bose/.test(n)) return "headphone";
	return "speaker";
}
function curve(gains) {
	return gains.length === BAND_COUNT ? gains.map((value) => clampDb(value)) : [...FLAT$1];
}
function createDevice(input) {
	const gains = curve((input.presetId ? presetById(input.presetId) ?? defaultPresetFor(input.kind) : defaultPresetFor(input.kind)).gains);
	return {
		id: input.id,
		name: input.name.slice(0, 40),
		kind: input.kind,
		origin: input.origin,
		sinkId: input.sinkId ?? null,
		battery: input.battery ?? null,
		gains,
		altGains: [...gains],
		ab: "a",
		preamp: 0,
		balance: 0,
		volume: .8,
		mono: false,
		loudness: false,
		crossfeed: input.kind === "earbud" || input.kind === "headphone",
		limiter: true
	};
}
function starterDevices() {
	return [
		createDevice({
			id: "dev-commute",
			name: "Commute Buds",
			kind: "earbud",
			origin: "demo"
		}),
		createDevice({
			id: "dev-desk",
			name: "Desk Speaker",
			kind: "speaker",
			origin: "demo"
		}),
		createDevice({
			id: "dev-room",
			name: "Living Room Bar",
			kind: "soundbar",
			origin: "demo"
		})
	];
}
function messageOf(error) {
	if (error instanceof DOMException) {
		if (error.name === "NotAllowedError") return "Permission blocked. Allow access, then try again.";
		if (error.name === "NotFoundError") return /cancel/i.test(error.message) ? "Cancelled." : "No matching device was found.";
		if (error.name === "NotSupportedError") return "This browser can't do that here.";
		if (error.name === "SecurityError") return "The browser blocked device access.";
		if (error.name === "AbortError") return "Cancelled.";
		if (error.message) return error.message;
	}
	if (error instanceof Error && error.message) return error.message;
	return "Something went wrong.";
}
var FLAT = [
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0
];
function shapedVolume(volume) {
	return Math.max(0, Math.min(1, volume)) ** 1.6;
}
var EqEngine = class {
	ctx = null;
	built = false;
	closed = false;
	token = 0;
	stops = [];
	toSpeakers = false;
	toStream = false;
	settings = {
		gains: [...FLAT],
		preamp: 0,
		volume: .8,
		balance: 0,
		mono: false,
		loudness: false,
		crossfeed: false,
		limiter: true,
		bypass: false
	};
	preamp;
	filters = [];
	lowLoud;
	highLoud;
	splitter;
	stereoL;
	stereoR;
	monoSendL;
	monoSendR;
	monoSum;
	monoToL;
	monoToR;
	xfFilterL;
	xfFilterR;
	xfDelayL;
	xfDelayR;
	xfGainL;
	xfGainR;
	leftSum;
	rightSum;
	balanceL;
	balanceR;
	merger;
	comp;
	master;
	spectrumAnalyser;
	meterL;
	meterR;
	streamDest = null;
	sinkEl = null;
	spectrum = null;
	meterLData = null;
	meterRData = null;
	isClosed() {
		return this.closed;
	}
	get sampleRate() {
		return this.ctx?.sampleRate ?? 48e3;
	}
	dispose() {
		this.stop();
		this.ctx?.close();
		this.closed = true;
		this.built = false;
		this.ctx = null;
	}
	ensureContext() {
		if (this.closed) throw new Error("Audio engine is closed.");
		if (!this.ctx || this.ctx.state === "closed") {
			this.ctx = new AudioContext();
			this.built = false;
			this.toSpeakers = false;
			this.toStream = false;
		}
		return this.ctx;
	}
	configure(settings) {
		this.settings = {
			...settings,
			gains: settings.gains.length === BANDS.length ? [...settings.gains] : [...FLAT]
		};
		if (this.built) this.apply(true);
	}
	async play(kind, buffer) {
		const token = ++this.token;
		this.stopSources();
		this.ensureGraph();
		const ctx = this.ctx;
		if (!ctx) return;
		if (ctx.state === "suspended") await ctx.resume();
		if (token !== this.token) return;
		if (kind === "file") {
			if (!buffer) throw new Error("Choose an audio file first.");
			this.startBuffer(buffer);
			return;
		}
		if (kind === "mic") {
			await this.startMic(token);
			return;
		}
		if (kind === "noise") {
			this.startBuffer(this.pinkBuffer());
			return;
		}
		if (kind === "ambient") {
			this.startAmbient();
			return;
		}
		if (kind === "voice") {
			this.startVoice();
			return;
		}
		this.startPulse();
	}
	stop() {
		this.token += 1;
		this.stopSources();
	}
	async route(sinkId) {
		this.ensureGraph();
		if (!sinkId) {
			this.routeDefault();
			return { ok: true };
		}
		const el = this.sinkEl;
		if (!el || typeof el.setSinkId !== "function") {
			this.routeDefault();
			return {
				ok: false,
				reason: "This browser plays through the default output. Set the earbuds or speaker as the system default, or open Halo EQ in Chrome."
			};
		}
		try {
			await el.setSinkId(sinkId);
			if (this.toSpeakers && this.ctx) {
				try {
					this.spectrumAnalyser.disconnect(this.ctx.destination);
				} catch {}
				this.toSpeakers = false;
			}
			if (!this.toStream && this.streamDest) {
				this.spectrumAnalyser.connect(this.streamDest);
				this.toStream = true;
			}
			await el.play();
			return { ok: true };
		} catch {
			this.routeDefault();
			return {
				ok: false,
				reason: "Couldn't switch outputs. Playing through the system default instead."
			};
		}
	}
	audition(freq) {
		const ctx = this.ensureContext();
		this.ensureGraph();
		const run = () => {
			const t = ctx.currentTime;
			const osc = ctx.createOscillator();
			osc.type = "sine";
			osc.frequency.value = freq;
			const gain = ctx.createGain();
			gain.gain.setValueAtTime(1e-4, t);
			gain.gain.exponentialRampToValueAtTime(.22, t + .02);
			gain.gain.exponentialRampToValueAtTime(1e-4, t + .28);
			osc.connect(gain);
			gain.connect(this.preamp);
			osc.start(t);
			osc.stop(t + .3);
		};
		if (ctx.state === "suspended") ctx.resume().then(run);
		else run();
	}
	getSpectrum() {
		if (!this.built || !this.spectrum) return null;
		this.spectrumAnalyser.getByteFrequencyData(this.spectrum);
		return this.spectrum;
	}
	getLevels() {
		if (!this.built || !this.meterLData || !this.meterRData) return {
			l: 0,
			r: 0,
			peak: 0
		};
		this.meterL.getFloatTimeDomainData(this.meterLData);
		this.meterR.getFloatTimeDomainData(this.meterRData);
		const left = levelOf(this.meterLData);
		const right = levelOf(this.meterRData);
		return {
			l: left.rms,
			r: right.rms,
			peak: Math.max(left.peak, right.peak)
		};
	}
	ensureGraph() {
		const ctx = this.ensureContext();
		if (this.built) return;
		const stereo = (node) => {
			node.channelCount = 2;
			node.channelCountMode = "explicit";
			node.channelInterpretation = "speakers";
		};
		this.preamp = ctx.createGain();
		stereo(this.preamp);
		this.filters = BANDS.map((band) => {
			const filter = ctx.createBiquadFilter();
			filter.type = "peaking";
			filter.frequency.value = band.hz;
			filter.Q.value = 1.41;
			filter.gain.value = 0;
			return filter;
		});
		this.lowLoud = ctx.createBiquadFilter();
		this.lowLoud.type = "lowshelf";
		this.lowLoud.frequency.value = 140;
		this.highLoud = ctx.createBiquadFilter();
		this.highLoud.type = "highshelf";
		this.highLoud.frequency.value = 8e3;
		this.splitter = ctx.createChannelSplitter(2);
		this.stereoL = ctx.createGain();
		this.stereoR = ctx.createGain();
		this.monoSendL = ctx.createGain();
		this.monoSendR = ctx.createGain();
		this.monoSum = ctx.createGain();
		this.monoToL = ctx.createGain();
		this.monoToR = ctx.createGain();
		this.xfFilterL = ctx.createBiquadFilter();
		this.xfFilterR = ctx.createBiquadFilter();
		this.xfFilterL.type = "lowpass";
		this.xfFilterR.type = "lowpass";
		this.xfFilterL.frequency.value = 800;
		this.xfFilterR.frequency.value = 800;
		this.xfDelayL = ctx.createDelay(.05);
		this.xfDelayR = ctx.createDelay(.05);
		this.xfDelayL.delayTime.value = 3e-4;
		this.xfDelayR.delayTime.value = 3e-4;
		this.xfGainL = ctx.createGain();
		this.xfGainR = ctx.createGain();
		this.leftSum = ctx.createGain();
		this.rightSum = ctx.createGain();
		this.balanceL = ctx.createGain();
		this.balanceR = ctx.createGain();
		this.merger = ctx.createChannelMerger(2);
		this.comp = ctx.createDynamicsCompressor();
		this.master = ctx.createGain();
		stereo(this.master);
		this.spectrumAnalyser = ctx.createAnalyser();
		this.spectrumAnalyser.fftSize = 2048;
		this.spectrumAnalyser.minDecibels = -90;
		this.spectrumAnalyser.maxDecibels = -22;
		this.spectrumAnalyser.smoothingTimeConstant = .78;
		this.spectrum = new Uint8Array(new ArrayBuffer(this.spectrumAnalyser.frequencyBinCount));
		this.meterL = ctx.createAnalyser();
		this.meterR = ctx.createAnalyser();
		this.meterL.fftSize = 256;
		this.meterR.fftSize = 256;
		this.meterL.smoothingTimeConstant = .45;
		this.meterR.smoothingTimeConstant = .45;
		this.meterLData = new Float32Array(/* @__PURE__ */ new ArrayBuffer(this.meterL.fftSize * 4));
		this.meterRData = new Float32Array(/* @__PURE__ */ new ArrayBuffer(this.meterR.fftSize * 4));
		this.streamDest = ctx.createMediaStreamDestination();
		const el = new Audio();
		el.srcObject = this.streamDest.stream;
		el.preload = "none";
		this.sinkEl = el;
		let node = this.preamp;
		for (const filter of this.filters) {
			node.connect(filter);
			node = filter;
		}
		node.connect(this.lowLoud);
		this.lowLoud.connect(this.highLoud);
		this.highLoud.connect(this.splitter);
		this.splitter.connect(this.stereoL, 0);
		this.splitter.connect(this.stereoR, 1);
		this.stereoL.connect(this.leftSum);
		this.stereoR.connect(this.rightSum);
		this.splitter.connect(this.monoSendL, 0);
		this.splitter.connect(this.monoSendR, 1);
		this.monoSendL.connect(this.monoSum);
		this.monoSendR.connect(this.monoSum);
		this.monoSum.connect(this.monoToL);
		this.monoSum.connect(this.monoToR);
		this.monoToL.connect(this.leftSum);
		this.monoToR.connect(this.rightSum);
		this.splitter.connect(this.xfFilterL, 0);
		this.xfFilterL.connect(this.xfDelayL);
		this.xfDelayL.connect(this.xfGainL);
		this.xfGainL.connect(this.rightSum);
		this.splitter.connect(this.xfFilterR, 1);
		this.xfFilterR.connect(this.xfDelayR);
		this.xfDelayR.connect(this.xfGainR);
		this.xfGainR.connect(this.leftSum);
		this.leftSum.connect(this.balanceL);
		this.rightSum.connect(this.balanceR);
		this.balanceL.connect(this.merger, 0, 0);
		this.balanceR.connect(this.merger, 0, 1);
		this.balanceL.connect(this.meterL);
		this.balanceR.connect(this.meterR);
		this.merger.connect(this.comp);
		this.comp.connect(this.master);
		this.master.connect(this.spectrumAnalyser);
		this.spectrumAnalyser.connect(ctx.destination);
		this.toSpeakers = true;
		this.built = true;
		this.apply(false);
	}
	apply(ramp) {
		const bypass = this.settings.bypass;
		const gains = bypass ? FLAT : this.settings.gains;
		this.filters.forEach((filter, index) => {
			this.setParam(filter.gain, gains[index] ?? 0, ramp);
		});
		const preampDb = bypass ? 0 : this.settings.preamp;
		this.setParam(this.preamp.gain, 10 ** (preampDb / 20), ramp);
		const volume = shapedVolume(this.settings.volume);
		this.setParam(this.master.gain, volume, ramp);
		const loud = !bypass && this.settings.loudness ? (1 - volume) * 9 : 0;
		this.setParam(this.lowLoud.gain, loud, ramp);
		this.setParam(this.highLoud.gain, loud * .55, ramp);
		const angle = (Math.max(-1, Math.min(1, this.settings.balance)) + 1) / 2 * (Math.PI / 2);
		this.setParam(this.balanceL.gain, Math.cos(angle), ramp);
		this.setParam(this.balanceR.gain, Math.sin(angle), ramp);
		const mono = this.settings.mono;
		this.setParam(this.stereoL.gain, mono ? 0 : 1, ramp);
		this.setParam(this.stereoR.gain, mono ? 0 : 1, ramp);
		this.setParam(this.monoSendL.gain, mono ? .5 : 0, ramp);
		this.setParam(this.monoSendR.gain, mono ? .5 : 0, ramp);
		this.setParam(this.monoToL.gain, mono ? 1 : 0, ramp);
		this.setParam(this.monoToR.gain, mono ? 1 : 0, ramp);
		const cross = !bypass && this.settings.crossfeed ? .38 : 0;
		this.setParam(this.xfGainL.gain, cross, ramp);
		this.setParam(this.xfGainR.gain, cross, ramp);
		if (this.settings.limiter) {
			this.setParam(this.comp.threshold, -10, ramp);
			this.setParam(this.comp.knee, 8, ramp);
			this.setParam(this.comp.ratio, 12, ramp);
			this.setParam(this.comp.attack, .003, ramp);
			this.setParam(this.comp.release, .18, ramp);
			return;
		}
		this.setParam(this.comp.threshold, 0, ramp);
		this.setParam(this.comp.knee, 0, ramp);
		this.setParam(this.comp.ratio, 1, ramp);
		this.setParam(this.comp.attack, .003, ramp);
		this.setParam(this.comp.release, .25, ramp);
	}
	setParam(param, value, ramp) {
		const ctx = this.ctx;
		if (!ctx) return;
		const now = ctx.currentTime;
		param.cancelScheduledValues(now);
		if (!ramp) {
			param.setValueAtTime(value, now);
			return;
		}
		param.setTargetAtTime(value, now, .03);
	}
	routeDefault() {
		if (this.toStream && this.streamDest) {
			try {
				this.spectrumAnalyser.disconnect(this.streamDest);
			} catch {}
			this.toStream = false;
		}
		this.sinkEl?.pause();
		if (!this.toSpeakers && this.ctx) {
			this.spectrumAnalyser.connect(this.ctx.destination);
			this.toSpeakers = true;
		}
	}
	stopSources() {
		for (const stop of this.stops) try {
			stop();
		} catch {}
		this.stops = [];
	}
	track(node, stop) {
		this.stops.push(() => {
			stop?.();
			try {
				node.disconnect();
			} catch {}
		});
	}
	startBuffer(buffer) {
		const ctx = this.ctx;
		if (!ctx) return;
		const source = ctx.createBufferSource();
		source.buffer = buffer;
		source.loop = true;
		source.connect(this.preamp);
		source.start();
		this.track(source, () => source.stop());
	}
	pinkBuffer() {
		const ctx = this.ctx;
		if (!ctx) throw new Error("Audio isn't ready.");
		const length = ctx.sampleRate * 2;
		const buffer = ctx.createBuffer(2, length, ctx.sampleRate);
		for (let channel = 0; channel < 2; channel += 1) {
			const data = buffer.getChannelData(channel);
			let b0 = 0;
			let b1 = 0;
			let b2 = 0;
			let b3 = 0;
			let b4 = 0;
			let b5 = 0;
			let b6 = 0;
			for (let i = 0; i < length; i += 1) {
				const white = Math.random() * 2 - 1;
				b0 = .99886 * b0 + white * .0555179;
				b1 = .99332 * b1 + white * .0750759;
				b2 = .969 * b2 + white * .153852;
				b3 = .8665 * b3 + white * .3104856;
				b4 = .55 * b4 + white * .5329522;
				b5 = -.7616 * b5 - white * .016898;
				const pink = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * .5362;
				b6 = white * .115926;
				data[i] = pink * .08;
			}
		}
		return buffer;
	}
	startAmbient() {
		const ctx = this.ctx;
		if (!ctx) return;
		[
			110,
			164.81,
			220,
			329.63
		].forEach((freq, index) => {
			const osc = ctx.createOscillator();
			osc.type = index % 2 === 0 ? "triangle" : "sine";
			osc.frequency.value = freq;
			osc.detune.value = (index - 1.5) * 4;
			const gain = ctx.createGain();
			gain.gain.value = .055;
			osc.connect(gain);
			gain.connect(this.preamp);
			osc.start();
			this.track(osc, () => osc.stop());
			this.track(gain);
		});
	}
	startVoice() {
		const ctx = this.ctx;
		if (!ctx) return;
		const osc = ctx.createOscillator();
		osc.type = "sawtooth";
		osc.frequency.value = 132;
		const vibrato = ctx.createOscillator();
		vibrato.frequency.value = 4.5;
		const vibratoGain = ctx.createGain();
		vibratoGain.gain.value = 3.5;
		vibrato.connect(vibratoGain);
		vibratoGain.connect(osc.frequency);
		const mix = ctx.createGain();
		mix.gain.value = .12;
		const low = ctx.createBiquadFilter();
		low.type = "bandpass";
		low.frequency.value = 700;
		low.Q.value = 4;
		const high = ctx.createBiquadFilter();
		high.type = "bandpass";
		high.frequency.value = 1400;
		high.Q.value = 5;
		osc.connect(low);
		osc.connect(high);
		low.connect(mix);
		high.connect(mix);
		mix.connect(this.preamp);
		osc.start();
		vibrato.start();
		this.track(osc, () => osc.stop());
		this.track(vibrato, () => vibrato.stop());
		this.track(mix);
	}
	startPulse() {
		const ctx = this.ctx;
		if (!ctx) return;
		const bass = ctx.createOscillator();
		bass.type = "sawtooth";
		bass.frequency.value = 55;
		const bassFilter = ctx.createBiquadFilter();
		bassFilter.type = "lowpass";
		bassFilter.frequency.value = 220;
		const bassGain = ctx.createGain();
		bassGain.gain.value = .18;
		bass.connect(bassFilter);
		bassFilter.connect(bassGain);
		bassGain.connect(this.preamp);
		bass.start();
		this.track(bass, () => bass.stop());
		const notes = [
			55,
			55,
			65.41,
			49
		];
		let step = 0;
		let alive = true;
		const kick = () => {
			const t = ctx.currentTime;
			const osc = ctx.createOscillator();
			osc.type = "sine";
			const gain = ctx.createGain();
			osc.frequency.setValueAtTime(150, t);
			osc.frequency.exponentialRampToValueAtTime(46, t + .12);
			gain.gain.setValueAtTime(.7, t);
			gain.gain.exponentialRampToValueAtTime(.001, t + .28);
			osc.connect(gain);
			gain.connect(this.preamp);
			osc.start(t);
			osc.stop(t + .3);
		};
		const hat = (level) => {
			const t = ctx.currentTime;
			const frames = Math.floor(ctx.sampleRate * .04);
			const buffer = ctx.createBuffer(1, frames, ctx.sampleRate);
			const data = buffer.getChannelData(0);
			for (let i = 0; i < frames; i += 1) data[i] = Math.random() * 2 - 1;
			const source = ctx.createBufferSource();
			source.buffer = buffer;
			const filter = ctx.createBiquadFilter();
			filter.type = "highpass";
			filter.frequency.value = 6500;
			const gain = ctx.createGain();
			gain.gain.setValueAtTime(level, t);
			gain.gain.exponentialRampToValueAtTime(.001, t + .04);
			source.connect(filter);
			filter.connect(gain);
			gain.connect(this.preamp);
			source.start(t);
		};
		const timer = window.setInterval(() => {
			if (!alive) return;
			if (step % 4 === 0) kick();
			if (step % 2 === 1) hat(.12);
			if (step % 8 === 4) hat(.16);
			bass.frequency.setTargetAtTime(notes[Math.floor(step / 4) % notes.length] ?? 55, ctx.currentTime, .02);
			step += 1;
		}, 175);
		this.stops.push(() => {
			alive = false;
			window.clearInterval(timer);
		});
	}
	async startMic(token) {
		const stream = await navigator.mediaDevices.getUserMedia({ audio: {
			echoCancellation: true,
			noiseSuppression: false
		} });
		if (token !== this.token) {
			stream.getTracks().forEach((track) => track.stop());
			return;
		}
		const ctx = this.ctx;
		if (!ctx) {
			stream.getTracks().forEach((track) => track.stop());
			return;
		}
		const source = ctx.createMediaStreamSource(stream);
		const gain = ctx.createGain();
		gain.gain.value = .9;
		source.connect(gain);
		gain.connect(this.preamp);
		this.track(source, () => stream.getTracks().forEach((track) => track.stop()));
		this.track(gain);
	}
};
function levelOf(data) {
	let sum = 0;
	let peak = 0;
	for (let i = 0; i < data.length; i += 1) {
		const sample = data[i] ?? 0;
		const abs = Math.abs(sample);
		if (abs > peak) peak = abs;
		sum += sample * sample;
	}
	return {
		rms: Math.sqrt(sum / data.length),
		peak
	};
}
var singleton = null;
function getEngine() {
	if (!singleton || singleton.isClosed()) singleton = new EqEngine();
	return singleton;
}
var PAD_X = 18;
var PAD_Y = 18;
var AXIS = [
	12,
	6,
	0,
	-6,
	-12
];
var FREQ_LABELS = /* @__PURE__ */ new Set([
	31,
	125,
	500,
	2e3,
	8e3,
	16e3
]);
function xOf(freq, width) {
	const min = Math.log(20);
	const max = Math.log(2e4);
	return PAD_X + (Math.log(freq) - min) / (max - min) * (width - 36);
}
function yOf(db, height) {
	return PAD_Y + (12 - Math.max(-12, Math.min(12, db))) / 24 * (height - 36);
}
function dbOf(y, height) {
	const span = height - 36;
	const t = span <= 0 ? 0 : (y - PAD_Y) / span;
	return Math.max(-12, Math.min(12, 12 - t * 24));
}
function curvePath(gains, width, height) {
	const points = BANDS.map((band, index) => ({
		x: xOf(band.hz, width),
		y: yOf(gains[index] ?? 0, height)
	}));
	const first = points[0];
	const last = points[points.length - 1];
	if (!first || !last) return "";
	let d = `M 0 ${first.y} L ${first.x} ${first.y}`;
	for (let i = 0; i < points.length - 1; i += 1) {
		const p0 = points[i - 1] ?? points[i];
		const p1 = points[i];
		const p2 = points[i + 1];
		const p3 = points[i + 2] ?? p2;
		if (!p0 || !p1 || !p2 || !p3) continue;
		const c1x = p1.x + (p2.x - p0.x) / 6;
		const c1y = p1.y + (p2.y - p0.y) / 6;
		const c2x = p2.x - (p3.x - p1.x) / 6;
		const c2y = p2.y - (p3.y - p1.y) / 6;
		d += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2.x} ${p2.y}`;
	}
	d += ` L ${width} ${last.y}`;
	return d;
}
function spectrumPath(data, sampleRate, width, height) {
	const min = Math.log(20);
	const max = Math.log(2e4);
	const nyquist = sampleRate / 2;
	const bottom = height - 8;
	let d = `M 0 ${bottom}`;
	const step = 6;
	for (let x = 0; x <= width; x += step) {
		const freq = Math.exp(min + x / Math.max(1, width) * (max - min));
		const y = bottom - (data[Math.min(data.length - 1, Math.max(0, Math.round(freq / nyquist * data.length)))] ?? 0) / 255 * (height - 36);
		d += ` L ${x} ${y}`;
	}
	d += ` L ${width} ${bottom} Z`;
	return d;
}
function EqCurve({ gains, playing, bypass, onChange }) {
	const wrapRef = (0, import_react.useRef)(null);
	const specRef = (0, import_react.useRef)(null);
	const gainsRef = (0, import_react.useRef)(gains);
	const dragRef = (0, import_react.useRef)(null);
	gainsRef.current = gains;
	const [size, setSize] = (0, import_react.useState)({
		w: 0,
		h: 0
	});
	(0, import_react.useEffect)(() => {
		const el = wrapRef.current;
		if (!el) return;
		const measure = () => {
			const rect = el.getBoundingClientRect();
			setSize({
				w: Math.max(1, rect.width),
				h: Math.max(1, rect.height)
			});
		};
		measure();
		const observer = new ResizeObserver(measure);
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		const spec = specRef.current;
		if (!playing) {
			spec?.setAttribute("d", "");
			return;
		}
		const smooth = { values: null };
		let frame = 0;
		const loop = () => {
			const engine = getEngine();
			const data = engine.getSpectrum();
			if (spec && data && size.w > 0) {
				if (!smooth.values || smooth.values.length !== data.length) smooth.values = new Float32Array(data.length);
				const values = smooth.values;
				for (let i = 0; i < data.length; i += 1) values[i] = values[i] * .72 + (data[i] ?? 0) * .28;
				spec.setAttribute("d", spectrumPath(values, engine.sampleRate, size.w, size.h));
			}
			frame = requestAnimationFrame(loop);
		};
		frame = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(frame);
	}, [
		playing,
		size.w,
		size.h
	]);
	const pointFromEvent = (event) => {
		const rect = event.currentTarget.getBoundingClientRect();
		return {
			x: (event.clientX - rect.left) / Math.max(1, rect.width) * size.w,
			y: (event.clientY - rect.top) / Math.max(1, rect.height) * size.h
		};
	};
	const nearest = (x, y) => {
		let best = -1;
		let bestDistance = 42;
		BANDS.forEach((band, index) => {
			const distance = Math.hypot(xOf(band.hz, size.w) - x, yOf(gainsRef.current[index] ?? 0, size.h) - y);
			if (distance < bestDistance) {
				bestDistance = distance;
				best = index;
			}
		});
		return best;
	};
	const onPointerDown = (event) => {
		if (size.w <= 0) return;
		const point = pointFromEvent(event);
		const index = nearest(point.x, point.y);
		if (index < 0) return;
		dragRef.current = index;
		event.currentTarget.setPointerCapture(event.pointerId);
		onChange(index, dbOf(point.y, size.h));
	};
	const onPointerMove = (event) => {
		const index = dragRef.current;
		if (index === null) return;
		onChange(index, dbOf(pointFromEvent(event).y, size.h));
	};
	const endDrag = () => {
		dragRef.current = null;
	};
	const path = size.w > 0 ? curvePath(gains, size.w, size.h) : "";
	const zero = size.h > 0 ? yOf(0, size.h) : 0;
	const fill = path ? `${path} L ${size.w} ${zero} L 0 ${zero} Z` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "relative h-56 w-full md:h-64",
		children: [
			size.w > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				className: "h-full w-full touch-none",
				viewBox: `0 0 ${size.w} ${size.h}`,
				role: "application",
				"aria-label": "Equalizer curve. Drag a point to change that band. Band sliders below do the same.",
				onPointerDown,
				onPointerMove,
				onPointerUp: endDrag,
				onPointerCancel: endDrag,
				children: [
					AXIS.map((db) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: 0,
						x2: size.w,
						y1: yOf(db, size.h),
						y2: yOf(db, size.h),
						className: db === 0 ? "stroke-border" : "stroke-border/50",
						strokeWidth: 1
					}, db)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						ref: specRef,
						className: "fill-primary/15"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: fill,
						className: bypass ? "fill-muted/20" : "fill-primary/25"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: path,
						className: bypass ? "stroke-muted" : "stroke-primary",
						fill: "none",
						strokeWidth: 2.5,
						strokeLinejoin: "round",
						strokeLinecap: "round"
					}),
					BANDS.map((band, index) => {
						const cx = xOf(band.hz, size.w);
						const cy = yOf(gains[index] ?? 0, size.h);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx,
							cy,
							r: 16,
							className: "fill-transparent"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx,
							cy,
							r: 5,
							className: bypass ? "fill-muted stroke-bg" : "fill-primary stroke-bg",
							strokeWidth: 2
						})] }, band.hz);
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute top-2 bottom-6 left-2 flex flex-col justify-between font-mono text-xs text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+12" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "0" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "-12" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-x-0 bottom-1",
				children: size.w > 0 ? BANDS.filter((band) => FREQ_LABELS.has(band.hz)).map((band) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute -translate-x-1/2 font-mono text-xs text-muted",
					style: { left: `${xOf(band.hz, size.w) / size.w * 100}%` },
					children: band.label
				}, band.hz)) : null
			})
		]
	});
}
function bluetoothAvailable() {
	return typeof navigator !== "undefined" && "bluetooth" in navigator;
}
async function queryOutputs() {
	if (typeof navigator === "undefined" || !navigator.mediaDevices?.enumerateDevices) return [];
	return (await navigator.mediaDevices.enumerateDevices()).filter((device) => device.kind === "audiooutput" && device.deviceId).map((device, index) => {
		const label = device.label?.trim() ?? "";
		return {
			deviceId: device.deviceId,
			label: label || (device.deviceId === "default" ? "System default" : `Output ${index + 1}`),
			unnamed: label.length === 0
		};
	});
}
async function unlockOutputNames() {
	(await navigator.mediaDevices.getUserMedia({ audio: true })).getTracks().forEach((track) => track.stop());
}
function bluetoothApi() {
	return navigator.bluetooth ?? null;
}
async function pairBluetooth() {
	const api = bluetoothApi();
	if (!api) throw new Error("Bluetooth scan isn't in this browser. Add earbuds from the system outputs list instead.");
	const device = await api.requestDevice({
		acceptAllDevices: true,
		optionalServices: ["battery_service"]
	});
	let battery = null;
	try {
		const server = await device.gatt?.connect();
		if (server) battery = (await (await (await server.getPrimaryService("battery_service")).getCharacteristic("battery_level")).readValue()).getUint8(0);
	} catch {
		battery = null;
	}
	return {
		id: device.id,
		name: device.name?.trim() || "Bluetooth device",
		battery
	};
}
var KEY = "halo-eq.v1";
var KINDS = /* @__PURE__ */ new Set([
	"earbud",
	"headphone",
	"speaker",
	"soundbar",
	"car"
]);
var ORIGINS = /* @__PURE__ */ new Set([
	"demo",
	"system",
	"bluetooth",
	"manual"
]);
var SOURCES = /* @__PURE__ */ new Set([
	"pulse",
	"ambient",
	"voice",
	"noise",
	"file",
	"mic"
]);
function writeSlot(device, gains) {
	const next = gains.map((value) => clampDb(value));
	if (device.ab === "a") return {
		...device,
		gains: next
	};
	return {
		...device,
		altGains: next
	};
}
function mapActive(devices, activeId, fn) {
	return devices.map((device) => device.id === activeId ? fn(device) : device);
}
function activeOf(state) {
	return state.devices.find((device) => device.id === state.activeId) ?? state.devices[0];
}
var useHalo = create((set, get) => ({
	devices: starterDevices(),
	activeId: "dev-commute",
	source: "pulse",
	customPresets: [],
	bypass: false,
	hydrated: false,
	hydrate: (data) => set({
		...data,
		bypass: false
	}),
	markHydrated: () => set({ hydrated: true }),
	setActive: (id) => {
		if (get().devices.some((device) => device.id === id)) set({ activeId: id });
	},
	updateActive: (patch) => {
		const { name, ...rest } = patch;
		set({ devices: mapActive(get().devices, get().activeId, (device) => ({
			...device,
			...rest,
			name: typeof name === "string" ? name.slice(0, 40) : device.name,
			preamp: clampDb(rest.preamp ?? device.preamp),
			balance: Math.max(-1, Math.min(1, rest.balance ?? device.balance)),
			volume: Math.max(0, Math.min(1, rest.volume ?? device.volume))
		})) });
	},
	setBand: (index, value) => {
		const device = activeOf(get());
		if (!device || index < 0 || index >= BAND_COUNT) return;
		const gains = liveGains(device).slice();
		gains[index] = clampDb(value);
		set({ devices: mapActive(get().devices, device.id, (current) => writeSlot(current, gains)) });
	},
	setLiveGains: (gains) => {
		const device = activeOf(get());
		if (!device) return;
		set({ devices: mapActive(get().devices, device.id, (current) => writeSlot(current, gains)) });
	},
	setGroupAverage: (group, value) => {
		const device = activeOf(get());
		if (!device) return;
		const gains = liveGains(device).slice();
		const current = groupAverage(gains, group);
		const delta = clampDb(value) - current;
		for (const index of groupIndexes(group)) gains[index] = clampDb((gains[index] ?? 0) + delta);
		set({ devices: mapActive(get().devices, device.id, (currentDevice) => writeSlot(currentDevice, gains)) });
	},
	setAb: (slot) => {
		set({ devices: mapActive(get().devices, get().activeId, (device) => ({
			...device,
			ab: slot
		})) });
	},
	copyAlt: () => {
		set({ devices: mapActive(get().devices, get().activeId, (device) => {
			if (device.ab === "a") return {
				...device,
				altGains: [...device.gains]
			};
			return {
				...device,
				gains: [...device.altGains]
			};
		}) });
	},
	resetLive: () => {
		const device = activeOf(get());
		if (!device) return;
		set({ devices: mapActive(get().devices, device.id, (current) => writeSlot(current, Array(BAND_COUNT).fill(0))) });
	},
	upsertDevice: (device) => {
		const devices = get().devices;
		const index = devices.findIndex((item) => item.id === device.id || device.sinkId !== null && item.sinkId === device.sinkId);
		if (index >= 0) {
			const prev = devices[index];
			if (!prev) return;
			const next = devices.slice();
			next[index] = {
				...prev,
				name: device.name.slice(0, 40),
				battery: device.battery ?? prev.battery,
				sinkId: device.sinkId ?? prev.sinkId,
				kind: device.kind
			};
			set({
				devices: next,
				activeId: prev.id
			});
			return;
		}
		set({
			devices: [...devices, device],
			activeId: device.id
		});
	},
	removeDevice: (id) => {
		const devices = get().devices;
		if (devices.length <= 1) return;
		const next = devices.filter((device) => device.id !== id);
		set({
			devices: next,
			activeId: get().activeId === id ? next[0]?.id ?? "" : get().activeId
		});
	},
	duplicateActive: () => {
		const device = activeOf(get());
		if (!device || typeof crypto === "undefined") return;
		const copy = {
			...device,
			id: `copy-${crypto.randomUUID()}`,
			name: device.name.endsWith(" alt") ? `${device.name} 2`.slice(0, 40) : `${device.name} alt`.slice(0, 40),
			origin: device.origin === "demo" ? "manual" : device.origin,
			gains: [...device.gains],
			altGains: [...device.altGains]
		};
		set({
			devices: [...get().devices, copy],
			activeId: copy.id
		});
	},
	setSource: (source) => set({ source }),
	toggleBypass: () => set({ bypass: !get().bypass }),
	addCustomPreset: (name) => {
		const trimmed = name.trim().slice(0, 24);
		const device = activeOf(get());
		if (!trimmed || !device) return false;
		if (get().customPresets.length >= 16) return false;
		const preset = {
			id: typeof crypto !== "undefined" ? `preset-${crypto.randomUUID()}` : `preset-${Date.now()}`,
			name: trimmed,
			gains: liveGains(device).map((value) => clampDb(value))
		};
		set({ customPresets: [...get().customPresets, preset] });
		return true;
	},
	removeCustomPreset: (id) => {
		set({ customPresets: get().customPresets.filter((preset) => preset.id !== id) });
	},
	applyPreset: (id) => {
		const custom = get().customPresets.find((preset) => preset.id === id);
		const built = PRESETS.find((preset) => preset.id === id);
		const gains = custom?.gains ?? built?.gains;
		if (!gains) return;
		get().setLiveGains(gains);
	}
}));
function isNumberList(value) {
	return Array.isArray(value) && value.length === BAND_COUNT && value.every((item) => typeof item === "number" && item >= -12 && item <= 12);
}
function isDevice(value) {
	if (!value || typeof value !== "object") return false;
	const device = value;
	return typeof device.id === "string" && typeof device.name === "string" && KINDS.has(device.kind) && ORIGINS.has(device.origin) && (device.sinkId === null || typeof device.sinkId === "string") && (device.battery === null || typeof device.battery === "number") && isNumberList(device.gains) && isNumberList(device.altGains) && (device.ab === "a" || device.ab === "b") && typeof device.preamp === "number" && typeof device.balance === "number" && typeof device.volume === "number" && typeof device.mono === "boolean" && typeof device.loudness === "boolean" && typeof device.crossfeed === "boolean" && typeof device.limiter === "boolean";
}
function loadPersisted() {
	if (typeof localStorage === "undefined") return null;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		const data = JSON.parse(raw);
		const devices = Array.isArray(data.devices) ? data.devices.filter(isDevice) : [];
		if (devices.length === 0) return null;
		return {
			devices,
			activeId: devices.some((device) => device.id === data.activeId) ? data.activeId : devices[0].id,
			source: SOURCES.has(data.source) ? data.source : "pulse",
			customPresets: Array.isArray(data.customPresets) ? data.customPresets.filter((preset) => !!preset && typeof preset === "object" && typeof preset.id === "string" && typeof preset.name === "string" && isNumberList(preset.gains)) : []
		};
	} catch {
		return null;
	}
}
function savePersisted(state) {
	if (typeof localStorage === "undefined") return;
	const data = {
		devices: state.devices,
		activeId: state.activeId,
		source: state.source,
		customPresets: state.customPresets
	};
	localStorage.setItem(KEY, JSON.stringify(data));
}
function KindIcon({ kind }) {
	const className = "size-5";
	if (kind === "earbud" || kind === "headphone") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, {
		className,
		"aria-hidden": true
	});
	if (kind === "soundbar") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {
		className,
		"aria-hidden": true
	});
	if (kind === "car") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, {
		className,
		"aria-hidden": true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Speaker, {
		className,
		"aria-hidden": true
	});
}
function DevicePanel() {
	const devices = useHalo((state) => state.devices);
	const activeId = useHalo((state) => state.activeId);
	const customPresets = useHalo((state) => state.customPresets);
	const setActive = useHalo((state) => state.setActive);
	const updateActive = useHalo((state) => state.updateActive);
	const upsertDevice = useHalo((state) => state.upsertDevice);
	const removeDevice = useHalo((state) => state.removeDevice);
	const duplicateActive = useHalo((state) => state.duplicateActive);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "min-w-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Devices"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setOpen(true),
					className: "inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-3 text-sm font-semibold text-primary-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "size-4",
						"aria-hidden": true
					}), "Add"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-w-0 gap-3 overflow-x-auto pb-1 lg:flex-col lg:overflow-visible",
				children: devices.map((device) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceCard, {
					device,
					active: device.id === activeId,
					presetName: identifyCurve(liveGains(device), customPresets).name,
					canDelete: devices.length > 1,
					onSelect: () => setActive(device.id),
					onRename: (name) => updateActive({ name }),
					onKind: (kind) => updateActive({ kind }),
					onDuplicate: duplicateActive,
					onDelete: () => removeDevice(device.id)
				}, device.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: "One device plays at a time. Each one keeps its own curve, volume, and tuning."
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddDeviceDialog, {
				onClose: () => setOpen(false),
				onAdd: upsertDevice
			}) : null
		]
	});
}
function DeviceCard({ device, active, presetName, canDelete, onSelect, onRename, onKind, onDuplicate, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: `min-w-64 rounded-xl border p-3 lg:min-w-0 ${active ? "border-primary bg-surface-2" : "border-border bg-surface"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onSelect,
			"aria-pressed": active,
			className: "flex w-full items-center gap-3 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-11 shrink-0 place-items-center rounded-lg bg-bg text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindIcon, { kind: device.kind })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-semibold",
						children: device.name
					}), active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "size-2 shrink-0 rounded-full bg-primary",
						"aria-hidden": true
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-0.5 block truncate text-xs text-muted",
					children: [
						kindLabel(device.kind),
						" · ",
						presetName,
						" · ",
						originLabel(device.origin),
						device.battery !== null ? ` · ${device.battery}%` : ""
					]
				})]
			})]
		}), active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 text-xs text-muted",
					children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: device.name,
						onChange: (event) => onRename(event.target.value),
						className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm text-fg",
						maxLength: 40
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 text-xs text-muted",
					children: ["Type", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: device.kind,
						onChange: (event) => onKind(event.target.value),
						className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm text-fg",
						children: KIND_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: option.id,
							children: option.label
						}, option.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onDuplicate,
						className: "inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg border border-border bg-bg text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
							className: "size-4",
							"aria-hidden": true
						}), "Duplicate"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onDelete,
						disabled: !canDelete,
						className: "inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg border border-border bg-bg text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
							className: "size-4",
							"aria-hidden": true
						}), "Remove"]
					})]
				})
			]
		}) : null]
	});
}
function AddDeviceDialog({ onClose, onAdd }) {
	const [outputs, setOutputs] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)(null);
	const [manualName, setManualName] = (0, import_react.useState)("");
	const [manualKind, setManualKind] = (0, import_react.useState)("earbud");
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [onClose]);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		queryOutputs().then((list) => {
			if (!cancel) setOutputs(list);
		}).catch((error) => {
			if (!cancel) setNote(messageOf(error));
		});
		return () => {
			cancel = true;
		};
	}, []);
	const refresh = async () => {
		setOutputs(await queryOutputs());
	};
	const addOutput = (output) => {
		onAdd(createDevice({
			id: `out-${output.deviceId}`,
			name: output.label,
			kind: guessKind(output.label),
			origin: "system",
			sinkId: output.deviceId
		}));
		onClose();
	};
	const scan = async () => {
		setBusy(true);
		setNote(null);
		try {
			const found = await pairBluetooth();
			onAdd(createDevice({
				id: `bt-${found.id}`,
				name: found.name,
				kind: guessKind(found.name),
				origin: "bluetooth",
				battery: found.battery
			}));
			onClose();
		} catch (error) {
			setNote(messageOf(error));
		} finally {
			setBusy(false);
		}
	};
	const unlock = async () => {
		setBusy(true);
		setNote(null);
		try {
			await unlockOutputNames();
			await refresh();
		} catch (error) {
			setNote(messageOf(error));
		} finally {
			setBusy(false);
		}
	};
	const addManual = () => {
		const name = manualName.trim();
		if (!name) {
			setNote("Name the device first.");
			return;
		}
		onAdd(createDevice({
			id: `manual-${crypto.randomUUID()}`,
			name,
			kind: manualKind,
			origin: "manual"
		}));
		onClose();
	};
	const unnamed = outputs.some((output) => output.unnamed);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-bg/70 sm:items-center sm:p-6",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "add-device-title",
			className: "max-h-full w-full overflow-y-auto border border-border bg-surface p-4 sm:max-w-md sm:rounded-xl",
			onClick: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						id: "add-device-title",
						className: "text-lg font-semibold",
						children: "Add a device"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Pick an output already connected to this phone or computer, scan Bluetooth, or save a manual profile."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						"aria-label": "Close",
						className: "grid size-11 place-items-center rounded-lg border border-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
							className: "size-4",
							"aria-hidden": true
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mb-2 text-sm font-semibold",
					children: "System outputs"
				}),
				outputs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "No outputs reported yet. Connect earbuds or a speaker, then refresh."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-3 grid gap-2",
					children: outputs.map((output) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => addOutput(output),
						className: "h-11 truncate rounded-lg border border-border bg-bg px-3 text-left text-sm",
						children: output.label
					}, output.deviceId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void refresh(),
						className: "h-11 rounded-lg border border-border px-3 text-sm",
						children: "Refresh"
					}), unnamed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						onClick: () => void unlock(),
						className: "h-11 rounded-lg border border-border px-3 text-sm",
						children: "Show names"
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mb-2 text-sm font-semibold",
					children: "Bluetooth"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: busy || !bluetoothAvailable(),
					onClick: () => void scan(),
					className: "mb-2 inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-border bg-bg text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bluetooth, {
						className: "size-4",
						"aria-hidden": true
					}), bluetoothAvailable() ? "Scan nearby Bluetooth" : "Bluetooth scan unavailable"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-xs text-muted",
					children: "A scan can save the device and its battery when the device shares it. Sound still plays through the system output you select."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mb-2 text-sm font-semibold",
					children: "Manual profile"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: manualName,
							onChange: (event) => setManualName(event.target.value),
							placeholder: "Kitchen speaker",
							"aria-label": "Device name",
							className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm",
							maxLength: 40
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: manualKind,
							"aria-label": "Device type",
							onChange: (event) => setManualKind(event.target.value),
							className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm",
							children: KIND_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: option.id,
								children: option.label
							}, option.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: addManual,
							className: "h-11 rounded-lg bg-primary text-sm font-semibold text-primary-fg",
							children: "Save profile"
						})
					]
				}),
				note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "mt-3 text-sm text-clip",
					children: note
				}) : null
			]
		})
	});
}
function HaloApp() {
	const devices = useHalo((state) => state.devices);
	const activeId = useHalo((state) => state.activeId);
	const source = useHalo((state) => state.source);
	const customPresets = useHalo((state) => state.customPresets);
	const bypass = useHalo((state) => state.bypass);
	const hydrated = useHalo((state) => state.hydrated);
	const setSource = useHalo((state) => state.setSource);
	const setBand = useHalo((state) => state.setBand);
	const setGroupAverage = useHalo((state) => state.setGroupAverage);
	const setAb = useHalo((state) => state.setAb);
	const copyAlt = useHalo((state) => state.copyAlt);
	const resetLive = useHalo((state) => state.resetLive);
	const updateActive = useHalo((state) => state.updateActive);
	const toggleBypass = useHalo((state) => state.toggleBypass);
	const applyPreset = useHalo((state) => state.applyPreset);
	const addCustomPreset = useHalo((state) => state.addCustomPreset);
	const removeCustomPreset = useHalo((state) => state.removeCustomPreset);
	const device = devices.find((item) => item.id === activeId) ?? devices[0] ?? null;
	const gains = device ? liveGains(device) : [];
	const preset = device ? identifyCurve(gains, customPresets) : {
		id: "flat",
		name: "Flat"
	};
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [routeNote, setRouteNote] = (0, import_react.useState)(null);
	const [fileName, setFileName] = (0, import_react.useState)(null);
	const [fileToken, setFileToken] = (0, import_react.useState)(0);
	const [presetName, setPresetName] = (0, import_react.useState)("");
	const [presetNote, setPresetNote] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	const fileInputRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const saved = loadPersisted();
		if (saved) useHalo.getState().hydrate(saved);
		useHalo.getState().markHydrated();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		savePersisted(useHalo.getState());
		return useHalo.subscribe((state) => savePersisted(state));
	}, [hydrated]);
	(0, import_react.useEffect)(() => {
		if (!device) return;
		getEngine().configure({
			gains,
			preamp: device.preamp,
			volume: device.volume,
			balance: device.balance,
			mono: device.mono,
			loudness: device.loudness,
			crossfeed: device.crossfeed,
			limiter: device.limiter,
			bypass
		});
	}, [
		device,
		gains,
		bypass
	]);
	(0, import_react.useEffect)(() => {
		if (!playing) {
			getEngine().stop();
			return;
		}
		let cancel = false;
		getEngine().play(source, fileRef.current).catch((err) => {
			if (cancel) return;
			setError(messageOf(err));
			setPlaying(false);
		});
		return () => {
			cancel = true;
		};
	}, [
		playing,
		source,
		fileToken
	]);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		let cancel = false;
		getEngine().route(device?.sinkId ?? null).then((result) => {
			if (!cancel) setRouteNote(result.ok ? null : result.reason ?? null);
		});
		return () => {
			cancel = true;
		};
	}, [playing, device?.sinkId]);
	const onFile = async (file) => {
		setError(null);
		try {
			const decoded = await getEngine().ensureContext().decodeAudioData(await file.arrayBuffer());
			fileRef.current = decoded;
			setFileName(file.name);
			setSource("file");
			setFileToken((token) => token + 1);
			setPlaying(true);
		} catch (err) {
			setError(messageOf(err) || "That file couldn't be read as audio.");
		}
	};
	const togglePlay = () => {
		setError(null);
		if (playing) {
			setPlaying(false);
			return;
		}
		if (source === "file" && !fileRef.current) {
			setError("Choose an audio file first.");
			fileInputRef.current?.click();
			return;
		}
		setPlaying(true);
	};
	const savePreset = () => {
		if (!addCustomPreset(presetName)) {
			setPresetNote(presetName.trim() ? "Delete a saved preset before adding another." : "Name the preset first.");
			return;
		}
		setPresetName("");
		setPresetNote(null);
	};
	const status = error ? error : routeNote ? routeNote : device ? `${labelForSource(source)} · ${device.name} · ${device.sinkId ? "selected output" : "system default"}` : "Add a device to start.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-6xl px-4 py-4 md:px-6 md:py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-4 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-11 place-items-center rounded-lg bg-primary text-primary-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaveMark, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold leading-none",
					children: "Halo EQ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Earbuds, speakers, and every device you switch"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meters, { playing }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipLamp, { playing })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-start gap-4 lg:grid-cols-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-w-0 lg:col-span-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DevicePanel, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid min-w-0 gap-4 lg:col-span-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-surface p-3 md:p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: togglePlay,
										"aria-label": playing ? "Pause" : "Play",
										className: "grid size-14 place-items-center rounded-full bg-primary text-primary-fg",
										children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
											className: "size-6",
											"aria-hidden": true
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
											className: "size-6 translate-x-0.5",
											"aria-hidden": true
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": bypass,
										onClick: toggleBypass,
										className: `h-11 rounded-lg px-4 text-sm font-semibold ${bypass ? "bg-primary text-primary-fg" : "border border-border bg-bg"}`,
										children: bypass ? "Bypass on" : "Bypass"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "grid min-w-48 flex-1 gap-1 text-xs text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex justify-between",
											children: ["Volume", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-fg",
												children: device ? Math.round(device.volume * 100) : 0
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: 0,
											max: 1,
											step: .01,
											value: device?.volume ?? .8,
											"aria-label": "Volume",
											onChange: (event) => updateActive({ volume: Number(event.target.value) })
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex gap-2 overflow-x-auto",
								children: [SOURCES$1.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": source === item.id,
									onClick: () => {
										setError(null);
										if (item.id === "file") {
											setSource("file");
											if (!fileRef.current) fileInputRef.current?.click();
											return;
										}
										setSource(item.id);
									},
									className: `h-11 shrink-0 rounded-full px-4 text-sm ${source === item.id ? "bg-primary font-semibold text-primary-fg" : "border border-border bg-bg"}`,
									children: item.label
								}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: fileInputRef,
									type: "file",
									accept: "audio/*,.mp3,.wav,.ogg,.m4a,.aac,.flac",
									className: "sr-only",
									onChange: (event) => {
										const file = event.target.files?.[0];
										if (file) onFile(file);
										event.target.value = "";
									}
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								role: error ? "alert" : "status",
								className: `mt-3 text-sm ${error || routeNote ? "text-clip" : "text-muted"}`,
								children: [status, fileName && source === "file" ? ` · ${fileName}` : ""]
							}),
							source === "mic" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Wear the earbuds so the microphone doesn't howl."
							}) : null,
							source === "noise" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Pink noise makes every band easy to hear."
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `rounded-xl border border-border bg-surface p-3 md:p-4 ${bypass ? "opacity-80" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-semibold",
									children: "Curve"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										preset.name,
										device ? ` · ${kindLabel(device.kind)}` : "",
										" · drag a point or a slider"
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex overflow-hidden rounded-lg border border-border",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-pressed": device?.ab === "a",
												onClick: () => setAb("a"),
												className: `h-11 px-4 text-sm font-semibold ${device?.ab === "a" ? "bg-primary text-primary-fg" : "bg-bg"}`,
												children: "A"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-pressed": device?.ab === "b",
												onClick: () => setAb("b"),
												className: `h-11 px-4 text-sm font-semibold ${device?.ab === "b" ? "bg-primary text-primary-fg" : "bg-bg"}`,
												children: "B"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: copyAlt,
											className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm",
											children: ["Copy to ", device?.ab === "a" ? "B" : "A"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: resetLive,
											className: "h-11 rounded-lg border border-border bg-bg px-3 text-sm",
											children: "Reset"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden rounded-lg border border-border bg-bg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EqCurve, {
									gains,
									playing,
									bypass,
									onChange: setBand
								})
							}),
							bypass ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-primary",
								children: "Bypass is on. You are hearing the signal without EQ."
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-2 text-sm font-semibold",
								children: "Presets"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 gap-2 overflow-x-auto pb-1",
								children: [PRESETS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									title: item.hint,
									"aria-pressed": preset.id === item.id,
									onClick: () => applyPreset(item.id),
									className: `h-11 shrink-0 rounded-full px-4 text-sm ${preset.id === item.id ? "bg-primary font-semibold text-primary-fg" : "border border-border bg-surface"}`,
									children: item.name
								}, item.id)), customPresets.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex shrink-0 overflow-hidden rounded-full border border-border",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": preset.id === item.id,
										onClick: () => applyPreset(item.id),
										className: `h-11 px-4 text-sm ${preset.id === item.id ? "bg-primary font-semibold text-primary-fg" : "bg-surface"}`,
										children: item.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": `Delete ${item.name}`,
										onClick: () => removeCustomPreset(item.id),
										className: "h-11 bg-surface px-3 text-sm text-muted",
										children: "Del"
									})]
								}, item.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "mt-2 flex gap-2",
								onSubmit: (event) => {
									event.preventDefault();
									savePreset();
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: presetName,
									onChange: (event) => setPresetName(event.target.value),
									placeholder: "Name this curve",
									"aria-label": "Preset name",
									maxLength: 24,
									className: "h-11 min-w-0 flex-1 rounded-lg border border-border bg-surface px-3 text-sm"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "h-11 shrink-0 rounded-lg border border-border bg-surface px-4 text-sm font-semibold",
									children: "Save preset"
								})]
							}),
							presetNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-clip",
								children: presetNote
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-surface p-3 md:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-baseline justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Bands"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Tap a frequency to hear it"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-1",
							children: BANDS.map((band, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-12 items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => getEngine().audition(band.hz),
										className: "col-span-2 h-11 text-left font-mono text-xs text-muted",
										children: band.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "col-span-8",
										type: "range",
										min: -12,
										max: 12,
										step: .1,
										value: gains[index] ?? 0,
										"aria-label": `${band.label} hertz`,
										onChange: (event) => setBand(index, Number(event.target.value)),
										onDoubleClick: () => setBand(index, 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "col-span-2 text-right font-mono text-xs",
										children: formatDb(gains[index] ?? 0)
									})
								]
							}, band.hz))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-border bg-surface p-3 md:p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-2 text-sm font-semibold",
								children: "Tone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToneSlider, {
										label: "Bass",
										group: "bass",
										gains,
										onChange: setGroupAverage
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToneSlider, {
										label: "Mid",
										group: "mid",
										gains,
										onChange: setGroupAverage
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToneSlider, {
										label: "Treble",
										group: "treble",
										gains,
										onChange: setGroupAverage
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "grid gap-1 text-xs text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex justify-between",
											children: ["Preamp", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-fg",
												children: formatDb(device?.preamp ?? 0)
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: -12,
											max: 12,
											step: .1,
											value: device?.preamp ?? 0,
											"aria-label": "Preamp",
											onChange: (event) => updateActive({ preamp: Number(event.target.value) }),
											onDoubleClick: () => updateActive({ preamp: 0 })
										})]
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-border bg-surface p-3 md:p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mb-2 text-sm font-semibold",
									children: "Output"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mb-3 grid gap-1 text-xs text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex justify-between",
										children: ["Balance", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-fg",
											children: formatBalance(device?.balance ?? 0)
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: -1,
										max: 1,
										step: .01,
										value: device?.balance ?? 0,
										"aria-label": "Balance",
										onChange: (event) => updateActive({ balance: Number(event.target.value) }),
										onDoubleClick: () => updateActive({ balance: 0 })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
											label: "Mono",
											on: device?.mono ?? false,
											onClick: () => updateActive({ mono: !device?.mono })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
											label: "Loudness",
											on: device?.loudness ?? false,
											onClick: () => updateActive({ loudness: !device?.loudness })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
											label: "Crossfeed",
											on: device?.crossfeed ?? false,
											onClick: () => updateActive({ crossfeed: !device?.crossfeed })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
											label: "Limiter",
											on: device?.limiter ?? false,
											onClick: () => updateActive({ limiter: !device?.limiter })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-xs text-muted",
									children: "Crossfeed is for earbuds. Loudness lifts lows and highs when the volume is down."
								})
							]
						})]
					})
				]
			})]
		})]
	});
}
function labelForSource(source) {
	return SOURCES$1.find((item) => item.id === source)?.label ?? "Pulse";
}
function ToneSlider({ label, group, gains, onChange }) {
	const average = gains.length ? groupAverage(gains, group) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1 text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex justify-between",
			children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-fg",
				children: formatDb(average)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min: -12,
			max: 12,
			step: .1,
			value: average,
			"aria-label": label,
			onChange: (event) => onChange(group, Number(event.target.value)),
			onDoubleClick: () => onChange(group, 0)
		})]
	});
}
function Toggle({ label, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: `h-11 rounded-lg text-sm font-semibold ${on ? "bg-primary text-primary-fg" : "border border-border bg-bg"}`,
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: on ? " on" : " off"
		})]
	});
}
function WaveMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-6",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M2 15c2-6 4 3 6 0s4 5 6 0 4 4 6 0",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round"
		})
	});
}
function Meters({ playing }) {
	const leftRef = (0, import_react.useRef)(null);
	const rightRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const paint = (value) => `scaleX(${Math.min(1, value * 2.8)})`;
		if (!playing) {
			if (leftRef.current) leftRef.current.style.transform = "scaleX(0)";
			if (rightRef.current) rightRef.current.style.transform = "scaleX(0)";
			return;
		}
		let frame = 0;
		const tick = () => {
			const levels = getEngine().getLevels();
			if (leftRef.current) leftRef.current.style.transform = paint(levels.l);
			if (rightRef.current) rightRef.current.style.transform = paint(levels.r);
			frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(frame);
	}, [playing]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-16 flex-col gap-1 sm:w-24",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-1.5 overflow-hidden rounded-full bg-surface-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: leftRef,
				className: "h-full w-full origin-left bg-primary",
				style: { transform: "scaleX(0)" }
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-1.5 overflow-hidden rounded-full bg-surface-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: rightRef,
				className: "h-full w-full origin-left bg-primary",
				style: { transform: "scaleX(0)" }
			})
		})]
	});
}
function ClipLamp({ playing }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let hold = 0;
		let frame = 0;
		if (!playing) {
			if (ref.current) ref.current.dataset.hot = "0";
			return;
		}
		const tick = () => {
			if (getEngine().getLevels().peak > .92) hold = 14;
			if (ref.current) ref.current.dataset.hot = hold > 0 ? "1" : "0";
			if (hold > 0) hold -= 1;
			frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(frame);
	}, [playing]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-2 text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			ref,
			"data-hot": "0",
			className: "size-2.5 rounded-full bg-border data-[hot=1]:bg-clip"
		}), "Clip"]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloApp, {});
}
//#endregion
export { Home as component };
