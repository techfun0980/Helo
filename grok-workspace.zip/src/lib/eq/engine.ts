import { BANDS, type SourceKind } from "@/lib/eq/model";

export type EqSettings = {
  gains: number[];
  preamp: number;
  volume: number;
  balance: number;
  mono: boolean;
  loudness: boolean;
  crossfeed: boolean;
  limiter: boolean;
  bypass: boolean;
};

export type RouteResult = { ok: boolean; reason?: string };

const FLAT = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

function shapedVolume(volume: number): number {
  const v = Math.max(0, Math.min(1, volume));
  return v ** 1.6;
}

export class EqEngine {
  private ctx: AudioContext | null = null;
  private built = false;
  private closed = false;
  private token = 0;
  private stops: Array<() => void> = [];
  private toSpeakers = false;
  private toStream = false;
  private settings: EqSettings = {
    gains: [...FLAT],
    preamp: 0,
    volume: 0.8,
    balance: 0,
    mono: false,
    loudness: false,
    crossfeed: false,
    limiter: true,
    bypass: false,
  };

  private preamp!: GainNode;
  private filters: BiquadFilterNode[] = [];
  private lowLoud!: BiquadFilterNode;
  private highLoud!: BiquadFilterNode;
  private splitter!: ChannelSplitterNode;
  private stereoL!: GainNode;
  private stereoR!: GainNode;
  private monoSendL!: GainNode;
  private monoSendR!: GainNode;
  private monoSum!: GainNode;
  private monoToL!: GainNode;
  private monoToR!: GainNode;
  private xfFilterL!: BiquadFilterNode;
  private xfFilterR!: BiquadFilterNode;
  private xfDelayL!: DelayNode;
  private xfDelayR!: DelayNode;
  private xfGainL!: GainNode;
  private xfGainR!: GainNode;
  private leftSum!: GainNode;
  private rightSum!: GainNode;
  private balanceL!: GainNode;
  private balanceR!: GainNode;
  private merger!: ChannelMergerNode;
  private comp!: DynamicsCompressorNode;
  private master!: GainNode;
  private spectrumAnalyser!: AnalyserNode;
  private meterL!: AnalyserNode;
  private meterR!: AnalyserNode;
  private streamDest: MediaStreamAudioDestinationNode | null = null;
  private sinkEl: HTMLAudioElement | null = null;
  private spectrum: Uint8Array<ArrayBuffer> | null = null;
  private meterLData: Float32Array<ArrayBuffer> | null = null;
  private meterRData: Float32Array<ArrayBuffer> | null = null;

  isClosed(): boolean {
    return this.closed;
  }

  get sampleRate(): number {
    return this.ctx?.sampleRate ?? 48000;
  }

  dispose(): void {
    this.stop();
    void this.ctx?.close();
    this.closed = true;
    this.built = false;
    this.ctx = null;
  }

  ensureContext(): AudioContext {
    if (this.closed) throw new Error("Audio engine is closed.");
    if (!this.ctx || this.ctx.state === "closed") {
      this.ctx = new AudioContext();
      this.built = false;
      this.toSpeakers = false;
      this.toStream = false;
    }
    return this.ctx;
  }

  configure(settings: EqSettings): void {
    this.settings = {
      ...settings,
      gains: settings.gains.length === BANDS.length ? [...settings.gains] : [...FLAT],
    };
    if (this.built) this.apply(true);
  }

  async play(kind: SourceKind, buffer: AudioBuffer | null): Promise<void> {
    const token = ++this.token;
    this.stopSources();
    this.ensureGraph();
    const ctx = this.ctx;
    if (!ctx) return;
    if (ctx.state === "suspended") await ctx.resume();
    if (token !== this.token) return;
    if (kind === "file") {
      if (!buffer) throw new Error("Choose an audio file first.");
      this.startBuffer(buffer);
      return;
    }
    if (kind === "mic") {
      await this.startMic(token);
      return;
    }
    if (kind === "noise") {
      this.startBuffer(this.pinkBuffer());
      return;
    }
    if (kind === "ambient") {
      this.startAmbient();
      return;
    }
    if (kind === "voice") {
      this.startVoice();
      return;
    }
    this.startPulse();
  }

  stop(): void {
    this.token += 1;
    this.stopSources();
  }

  async route(sinkId: string | null): Promise<RouteResult> {
    this.ensureGraph();
    if (!sinkId) {
      this.routeDefault();
      return { ok: true };
    }
    const el = this.sinkEl;
    if (!el || typeof el.setSinkId !== "function") {
      this.routeDefault();
      return {
        ok: false,
        reason: "This browser plays through the default output. Set the earbuds or speaker as the system default, or open Halo EQ in Chrome.",
      };
    }
    try {
      await el.setSinkId(sinkId);
      if (this.toSpeakers && this.ctx) {
        try {
          this.spectrumAnalyser.disconnect(this.ctx.destination);
        } catch {
          /* already disconnected */
        }
        this.toSpeakers = false;
      }
      if (!this.toStream && this.streamDest) {
        this.spectrumAnalyser.connect(this.streamDest);
        this.toStream = true;
      }
      await el.play();
      return { ok: true };
    } catch {
      this.routeDefault();
      return { ok: false, reason: "Couldn't switch outputs. Playing through the system default instead." };
    }
  }

  audition(freq: number): void {
    const ctx = this.ensureContext();
    this.ensureGraph();
    const run = () => {
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freq;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.22, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.28);
      osc.connect(gain);
      gain.connect(this.preamp);
      osc.start(t);
      osc.stop(t + 0.3);
    };
    if (ctx.state === "suspended") void ctx.resume().then(run);
    else run();
  }

  getSpectrum(): Uint8Array<ArrayBuffer> | null {
    if (!this.built || !this.spectrum) return null;
    this.spectrumAnalyser.getByteFrequencyData(this.spectrum);
    return this.spectrum;
  }

  getLevels(): { l: number; r: number; peak: number } {
    if (!this.built || !this.meterLData || !this.meterRData) return { l: 0, r: 0, peak: 0 };
    this.meterL.getFloatTimeDomainData(this.meterLData);
    this.meterR.getFloatTimeDomainData(this.meterRData);
    const left = levelOf(this.meterLData);
    const right = levelOf(this.meterRData);
    return { l: left.rms, r: right.rms, peak: Math.max(left.peak, right.peak) };
  }

  private ensureGraph(): void {
    const ctx = this.ensureContext();
    if (this.built) return;

    const stereo = (node: AudioNode) => {
      node.channelCount = 2;
      node.channelCountMode = "explicit";
      node.channelInterpretation = "speakers";
    };

    this.preamp = ctx.createGain();
    stereo(this.preamp);

    this.filters = BANDS.map((band) => {
      const filter = ctx.createBiquadFilter();
      filter.type = "peaking";
      filter.frequency.value = band.hz;
      filter.Q.value = 1.41;
      filter.gain.value = 0;
      return filter;
    });

    this.lowLoud = ctx.createBiquadFilter();
    this.lowLoud.type = "lowshelf";
    this.lowLoud.frequency.value = 140;
    this.highLoud = ctx.createBiquadFilter();
    this.highLoud.type = "highshelf";
    this.highLoud.frequency.value = 8000;

    this.splitter = ctx.createChannelSplitter(2);
    this.stereoL = ctx.createGain();
    this.stereoR = ctx.createGain();
    this.monoSendL = ctx.createGain();
    this.monoSendR = ctx.createGain();
    this.monoSum = ctx.createGain();
    this.monoToL = ctx.createGain();
    this.monoToR = ctx.createGain();

    this.xfFilterL = ctx.createBiquadFilter();
    this.xfFilterR = ctx.createBiquadFilter();
    this.xfFilterL.type = "lowpass";
    this.xfFilterR.type = "lowpass";
    this.xfFilterL.frequency.value = 800;
    this.xfFilterR.frequency.value = 800;
    this.xfDelayL = ctx.createDelay(0.05);
    this.xfDelayR = ctx.createDelay(0.05);
    this.xfDelayL.delayTime.value = 0.0003;
    this.xfDelayR.delayTime.value = 0.0003;
    this.xfGainL = ctx.createGain();
    this.xfGainR = ctx.createGain();

    this.leftSum = ctx.createGain();
    this.rightSum = ctx.createGain();
    this.balanceL = ctx.createGain();
    this.balanceR = ctx.createGain();
    this.merger = ctx.createChannelMerger(2);
    this.comp = ctx.createDynamicsCompressor();
    this.master = ctx.createGain();
    stereo(this.master);

    this.spectrumAnalyser = ctx.createAnalyser();
    this.spectrumAnalyser.fftSize = 2048;
    this.spectrumAnalyser.minDecibels = -90;
    this.spectrumAnalyser.maxDecibels = -22;
    this.spectrumAnalyser.smoothingTimeConstant = 0.78;
    this.spectrum = new Uint8Array(new ArrayBuffer(this.spectrumAnalyser.frequencyBinCount));

    this.meterL = ctx.createAnalyser();
    this.meterR = ctx.createAnalyser();
    this.meterL.fftSize = 256;
    this.meterR.fftSize = 256;
    this.meterL.smoothingTimeConstant = 0.45;
    this.meterR.smoothingTimeConstant = 0.45;
    this.meterLData = new Float32Array(new ArrayBuffer(this.meterL.fftSize * 4));
    this.meterRData = new Float32Array(new ArrayBuffer(this.meterR.fftSize * 4));

    this.streamDest = ctx.createMediaStreamDestination();
    const el = new Audio();
    el.srcObject = this.streamDest.stream;
    el.preload = "none";
    this.sinkEl = el;

    let node: AudioNode = this.preamp;
    for (const filter of this.filters) {
      node.connect(filter);
      node = filter;
    }
    node.connect(this.lowLoud);
    this.lowLoud.connect(this.highLoud);
    this.highLoud.connect(this.splitter);

    this.splitter.connect(this.stereoL, 0);
    this.splitter.connect(this.stereoR, 1);
    this.stereoL.connect(this.leftSum);
    this.stereoR.connect(this.rightSum);

    this.splitter.connect(this.monoSendL, 0);
    this.splitter.connect(this.monoSendR, 1);
    this.monoSendL.connect(this.monoSum);
    this.monoSendR.connect(this.monoSum);
    this.monoSum.connect(this.monoToL);
    this.monoSum.connect(this.monoToR);
    this.monoToL.connect(this.leftSum);
    this.monoToR.connect(this.rightSum);

    this.splitter.connect(this.xfFilterL, 0);
    this.xfFilterL.connect(this.xfDelayL);
    this.xfDelayL.connect(this.xfGainL);
    this.xfGainL.connect(this.rightSum);
    this.splitter.connect(this.xfFilterR, 1);
    this.xfFilterR.connect(this.xfDelayR);
    this.xfDelayR.connect(this.xfGainR);
    this.xfGainR.connect(this.leftSum);

    this.leftSum.connect(this.balanceL);
    this.rightSum.connect(this.balanceR);
    this.balanceL.connect(this.merger, 0, 0);
    this.balanceR.connect(this.merger, 0, 1);
    this.balanceL.connect(this.meterL);
    this.balanceR.connect(this.meterR);

    this.merger.connect(this.comp);
    this.comp.connect(this.master);
    this.master.connect(this.spectrumAnalyser);
    this.spectrumAnalyser.connect(ctx.destination);
    this.toSpeakers = true;

    this.built = true;
    this.apply(false);
  }

  private apply(ramp: boolean): void {
    const bypass = this.settings.bypass;
    const gains = bypass ? FLAT : this.settings.gains;
    this.filters.forEach((filter, index) => {
      this.setParam(filter.gain, gains[index] ?? 0, ramp);
    });
    const preampDb = bypass ? 0 : this.settings.preamp;
    this.setParam(this.preamp.gain, 10 ** (preampDb / 20), ramp);

    const volume = shapedVolume(this.settings.volume);
    this.setParam(this.master.gain, volume, ramp);

    const loud = !bypass && this.settings.loudness ? (1 - volume) * 9 : 0;
    this.setParam(this.lowLoud.gain, loud, ramp);
    this.setParam(this.highLoud.gain, loud * 0.55, ramp);

    const pan = Math.max(-1, Math.min(1, this.settings.balance));
    const angle = ((pan + 1) / 2) * (Math.PI / 2);
    this.setParam(this.balanceL.gain, Math.cos(angle), ramp);
    this.setParam(this.balanceR.gain, Math.sin(angle), ramp);

    const mono = this.settings.mono;
    this.setParam(this.stereoL.gain, mono ? 0 : 1, ramp);
    this.setParam(this.stereoR.gain, mono ? 0 : 1, ramp);
    this.setParam(this.monoSendL.gain, mono ? 0.5 : 0, ramp);
    this.setParam(this.monoSendR.gain, mono ? 0.5 : 0, ramp);
    this.setParam(this.monoToL.gain, mono ? 1 : 0, ramp);
    this.setParam(this.monoToR.gain, mono ? 1 : 0, ramp);

    const cross = !bypass && this.settings.crossfeed ? 0.38 : 0;
    this.setParam(this.xfGainL.gain, cross, ramp);
    this.setParam(this.xfGainR.gain, cross, ramp);

    if (this.settings.limiter) {
      this.setParam(this.comp.threshold, -10, ramp);
      this.setParam(this.comp.knee, 8, ramp);
      this.setParam(this.comp.ratio, 12, ramp);
      this.setParam(this.comp.attack, 0.003, ramp);
      this.setParam(this.comp.release, 0.18, ramp);
      return;
    }
    this.setParam(this.comp.threshold, 0, ramp);
    this.setParam(this.comp.knee, 0, ramp);
    this.setParam(this.comp.ratio, 1, ramp);
    this.setParam(this.comp.attack, 0.003, ramp);
    this.setParam(this.comp.release, 0.25, ramp);
  }

  private setParam(param: AudioParam, value: number, ramp: boolean): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    param.cancelScheduledValues(now);
    if (!ramp) {
      param.setValueAtTime(value, now);
      return;
    }
    param.setTargetAtTime(value, now, 0.03);
  }

  private routeDefault(): void {
    if (this.toStream && this.streamDest) {
      try {
        this.spectrumAnalyser.disconnect(this.streamDest);
      } catch {
        /* already disconnected */
      }
      this.toStream = false;
    }
    this.sinkEl?.pause();
    if (!this.toSpeakers && this.ctx) {
      this.spectrumAnalyser.connect(this.ctx.destination);
      this.toSpeakers = true;
    }
  }

  private stopSources(): void {
    for (const stop of this.stops) {
      try {
        stop();
      } catch {
        /* node already stopped */
      }
    }
    this.stops = [];
  }

  private track(node: AudioNode, stop?: () => void): void {
    this.stops.push(() => {
      stop?.();
      try {
        node.disconnect();
      } catch {
        /* already disconnected */
      }
    });
  }

  private startBuffer(buffer: AudioBuffer): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;
    source.connect(this.preamp);
    source.start();
    this.track(source, () => source.stop());
  }

  private pinkBuffer(): AudioBuffer {
    const ctx = this.ctx;
    if (!ctx) throw new Error("Audio isn't ready.");
    const length = ctx.sampleRate * 2;
    const buffer = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let channel = 0; channel < 2; channel += 1) {
      const data = buffer.getChannelData(channel);
      let b0 = 0;
      let b1 = 0;
      let b2 = 0;
      let b3 = 0;
      let b4 = 0;
      let b5 = 0;
      let b6 = 0;
      for (let i = 0; i < length; i += 1) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.969 * b2 + white * 0.153852;
        b3 = 0.8665 * b3 + white * 0.3104856;
        b4 = 0.55 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.016898;
        const pink = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        b6 = white * 0.115926;
        data[i] = pink * 0.08;
      }
    }
    return buffer;
  }

  private startAmbient(): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const notes = [110, 164.81, 220, 329.63];
    notes.forEach((freq, index) => {
      const osc = ctx.createOscillator();
      osc.type = index % 2 === 0 ? "triangle" : "sine";
      osc.frequency.value = freq;
      osc.detune.value = (index - 1.5) * 4;
      const gain = ctx.createGain();
      gain.gain.value = 0.055;
      osc.connect(gain);
      gain.connect(this.preamp);
      osc.start();
      this.track(osc, () => osc.stop());
      this.track(gain);
    });
  }

  private startVoice(): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.value = 132;
    const vibrato = ctx.createOscillator();
    vibrato.frequency.value = 4.5;
    const vibratoGain = ctx.createGain();
    vibratoGain.gain.value = 3.5;
    vibrato.connect(vibratoGain);
    vibratoGain.connect(osc.frequency);
    const mix = ctx.createGain();
    mix.gain.value = 0.12;
    const low = ctx.createBiquadFilter();
    low.type = "bandpass";
    low.frequency.value = 700;
    low.Q.value = 4;
    const high = ctx.createBiquadFilter();
    high.type = "bandpass";
    high.frequency.value = 1400;
    high.Q.value = 5;
    osc.connect(low);
    osc.connect(high);
    low.connect(mix);
    high.connect(mix);
    mix.connect(this.preamp);
    osc.start();
    vibrato.start();
    this.track(osc, () => osc.stop());
    this.track(vibrato, () => vibrato.stop());
    this.track(mix);
  }

  private startPulse(): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const bass = ctx.createOscillator();
    bass.type = "sawtooth";
    bass.frequency.value = 55;
    const bassFilter = ctx.createBiquadFilter();
    bassFilter.type = "lowpass";
    bassFilter.frequency.value = 220;
    const bassGain = ctx.createGain();
    bassGain.gain.value = 0.18;
    bass.connect(bassFilter);
    bassFilter.connect(bassGain);
    bassGain.connect(this.preamp);
    bass.start();
    this.track(bass, () => bass.stop());

    const notes = [55, 55, 65.41, 49];
    let step = 0;
    let alive = true;
    const kick = () => {
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      osc.type = "sine";
      const gain = ctx.createGain();
      osc.frequency.setValueAtTime(150, t);
      osc.frequency.exponentialRampToValueAtTime(46, t + 0.12);
      gain.gain.setValueAtTime(0.7, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
      osc.connect(gain);
      gain.connect(this.preamp);
      osc.start(t);
      osc.stop(t + 0.3);
    };
    const hat = (level: number) => {
      const t = ctx.currentTime;
      const frames = Math.floor(ctx.sampleRate * 0.04);
      const buffer = ctx.createBuffer(1, frames, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < frames; i += 1) data[i] = Math.random() * 2 - 1;
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = "highpass";
      filter.frequency.value = 6500;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(level, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
      source.connect(filter);
      filter.connect(gain);
      gain.connect(this.preamp);
      source.start(t);
    };
    const timer = window.setInterval(() => {
      if (!alive) return;
      if (step % 4 === 0) kick();
      if (step % 2 === 1) hat(0.12);
      if (step % 8 === 4) hat(0.16);
      bass.frequency.setTargetAtTime(notes[Math.floor(step / 4) % notes.length] ?? 55, ctx.currentTime, 0.02);
      step += 1;
    }, 175);
    this.stops.push(() => {
      alive = false;
      window.clearInterval(timer);
    });
  }

  private async startMic(token: number): Promise<void> {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: false },
    });
    if (token !== this.token) {
      stream.getTracks().forEach((track) => track.stop());
      return;
    }
    const ctx = this.ctx;
    if (!ctx) {
      stream.getTracks().forEach((track) => track.stop());
      return;
    }
    const source = ctx.createMediaStreamSource(stream);
    const gain = ctx.createGain();
    gain.gain.value = 0.9;
    source.connect(gain);
    gain.connect(this.preamp);
    this.track(source, () => stream.getTracks().forEach((track) => track.stop()));
    this.track(gain);
  }
}

function levelOf(data: Float32Array): { rms: number; peak: number } {
  let sum = 0;
  let peak = 0;
  for (let i = 0; i < data.length; i += 1) {
    const sample = data[i] ?? 0;
    const abs = Math.abs(sample);
    if (abs > peak) peak = abs;
    sum += sample * sample;
  }
  return { rms: Math.sqrt(sum / data.length), peak };
}

let singleton: EqEngine | null = null;

export function getEngine(): EqEngine {
  if (!singleton || singleton.isClosed()) singleton = new EqEngine();
  return singleton;
}

if (import.meta.hot) {
  import.meta.hot.dispose(() => {
    singleton?.dispose();
    singleton = null;
  });
}
