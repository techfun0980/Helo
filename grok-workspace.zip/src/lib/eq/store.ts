import { create } from "zustand";
import {
  BAND_COUNT,
  clampDb,
  createDevice,
  groupIndexes,
  groupAverage,
  liveGains,
  PRESETS,
  starterDevices,
  type AbSlot,
  type CustomPreset,
  type DeviceKind,
  type DeviceOrigin,
  type DeviceProfile,
  type SourceKind,
  type ToneGroup,
} from "@/lib/eq/model";

const KEY = "halo-eq.v1";
const KINDS = new Set<DeviceKind>(["earbud", "headphone", "speaker", "soundbar", "car"]);
const ORIGINS = new Set<DeviceOrigin>(["demo", "system", "bluetooth", "manual"]);
const SOURCES = new Set<SourceKind>(["pulse", "ambient", "voice", "noise", "file", "mic"]);

type Persisted = {
  devices: DeviceProfile[];
  activeId: string;
  source: SourceKind;
  customPresets: CustomPreset[];
};

type HaloState = Persisted & {
  bypass: boolean;
  hydrated: boolean;
  hydrate: (data: Persisted) => void;
  markHydrated: () => void;
  setActive: (id: string) => void;
  updateActive: (patch: Partial<DeviceProfile>) => void;
  setBand: (index: number, value: number) => void;
  setLiveGains: (gains: number[]) => void;
  setGroupAverage: (group: ToneGroup, value: number) => void;
  setAb: (slot: AbSlot) => void;
  copyAlt: () => void;
  resetLive: () => void;
  upsertDevice: (device: DeviceProfile) => void;
  removeDevice: (id: string) => void;
  duplicateActive: () => void;
  setSource: (source: SourceKind) => void;
  toggleBypass: () => void;
  addCustomPreset: (name: string) => boolean;
  removeCustomPreset: (id: string) => void;
  applyPreset: (id: string) => void;
};

function writeSlot(device: DeviceProfile, gains: number[]): DeviceProfile {
  const next = gains.map((value) => clampDb(value));
  if (device.ab === "a") return { ...device, gains: next };
  return { ...device, altGains: next };
}

function mapActive(devices: DeviceProfile[], activeId: string, fn: (device: DeviceProfile) => DeviceProfile) {
  return devices.map((device) => (device.id === activeId ? fn(device) : device));
}

function activeOf(state: HaloState): DeviceProfile | undefined {
  return state.devices.find((device) => device.id === state.activeId) ?? state.devices[0];
}

export const useHalo = create<HaloState>((set, get) => ({
  devices: starterDevices(),
  activeId: "dev-commute",
  source: "pulse",
  customPresets: [],
  bypass: false,
  hydrated: false,
  hydrate: (data) => set({ ...data, bypass: false }),
  markHydrated: () => set({ hydrated: true }),
  setActive: (id) => {
    if (get().devices.some((device) => device.id === id)) set({ activeId: id });
  },
  updateActive: (patch) => {
    const { name, ...rest } = patch;
    set({
      devices: mapActive(get().devices, get().activeId, (device) => ({
        ...device,
        ...rest,
        name: typeof name === "string" ? name.slice(0, 40) : device.name,
        preamp: clampDb(rest.preamp ?? device.preamp),
        balance: Math.max(-1, Math.min(1, rest.balance ?? device.balance)),
        volume: Math.max(0, Math.min(1, rest.volume ?? device.volume)),
      })),
    });
  },
  setBand: (index, value) => {
    const device = activeOf(get());
    if (!device || index < 0 || index >= BAND_COUNT) return;
    const gains = liveGains(device).slice();
    gains[index] = clampDb(value);
    set({ devices: mapActive(get().devices, device.id, (current) => writeSlot(current, gains)) });
  },
  setLiveGains: (gains) => {
    const device = activeOf(get());
    if (!device) return;
    set({ devices: mapActive(get().devices, device.id, (current) => writeSlot(current, gains)) });
  },
  setGroupAverage: (group, value) => {
    const device = activeOf(get());
    if (!device) return;
    const gains = liveGains(device).slice();
    const current = groupAverage(gains, group);
    const delta = clampDb(value) - current;
    for (const index of groupIndexes(group)) gains[index] = clampDb((gains[index] ?? 0) + delta);
    set({ devices: mapActive(get().devices, device.id, (currentDevice) => writeSlot(currentDevice, gains)) });
  },
  setAb: (slot) => {
    set({ devices: mapActive(get().devices, get().activeId, (device) => ({ ...device, ab: slot })) });
  },
  copyAlt: () => {
    set({
      devices: mapActive(get().devices, get().activeId, (device) => {
        if (device.ab === "a") return { ...device, altGains: [...device.gains] };
        return { ...device, gains: [...device.altGains] };
      }),
    });
  },
  resetLive: () => {
    const device = activeOf(get());
    if (!device) return;
    set({
      devices: mapActive(get().devices, device.id, (current) => writeSlot(current, Array(BAND_COUNT).fill(0))),
    });
  },
  upsertDevice: (device) => {
    const devices = get().devices;
    const index = devices.findIndex(
      (item) => item.id === device.id || (device.sinkId !== null && item.sinkId === device.sinkId),
    );
    if (index >= 0) {
      const prev = devices[index];
      if (!prev) return;
      const next = devices.slice();
      next[index] = {
        ...prev,
        name: device.name.slice(0, 40),
        battery: device.battery ?? prev.battery,
        sinkId: device.sinkId ?? prev.sinkId,
        kind: device.kind,
      };
      set({ devices: next, activeId: prev.id });
      return;
    }
    set({ devices: [...devices, device], activeId: device.id });
  },
  removeDevice: (id) => {
    const devices = get().devices;
    if (devices.length <= 1) return;
    const next = devices.filter((device) => device.id !== id);
    const activeId = get().activeId === id ? (next[0]?.id ?? "") : get().activeId;
    set({ devices: next, activeId });
  },
  duplicateActive: () => {
    const device = activeOf(get());
    if (!device || typeof crypto === "undefined") return;
    const copy: DeviceProfile = {
      ...device,
      id: `copy-${crypto.randomUUID()}`,
      name: device.name.endsWith(" alt") ? `${device.name} 2`.slice(0, 40) : `${device.name} alt`.slice(0, 40),
      origin: device.origin === "demo" ? "manual" : device.origin,
      gains: [...device.gains],
      altGains: [...device.altGains],
    };
    set({ devices: [...get().devices, copy], activeId: copy.id });
  },
  setSource: (source) => set({ source }),
  toggleBypass: () => set({ bypass: !get().bypass }),
  addCustomPreset: (name) => {
    const trimmed = name.trim().slice(0, 24);
    const device = activeOf(get());
    if (!trimmed || !device) return false;
    if (get().customPresets.length >= 16) return false;
    const preset: CustomPreset = {
      id: typeof crypto !== "undefined" ? `preset-${crypto.randomUUID()}` : `preset-${Date.now()}`,
      name: trimmed,
      gains: liveGains(device).map((value) => clampDb(value)),
    };
    set({ customPresets: [...get().customPresets, preset] });
    return true;
  },
  removeCustomPreset: (id) => {
    set({ customPresets: get().customPresets.filter((preset) => preset.id !== id) });
  },
  applyPreset: (id) => {
    const custom = get().customPresets.find((preset) => preset.id === id);
    const built = PRESETS.find((preset) => preset.id === id);
    const gains = custom?.gains ?? built?.gains;
    if (!gains) return;
    get().setLiveGains(gains);
  },
}));

function isNumberList(value: unknown): value is number[] {
  return Array.isArray(value) && value.length === BAND_COUNT && value.every((item) => typeof item === "number" && item >= -12 && item <= 12);
}

function isDevice(value: unknown): value is DeviceProfile {
  if (!value || typeof value !== "object") return false;
  const device = value as DeviceProfile;
  return (
    typeof device.id === "string" &&
    typeof device.name === "string" &&
    KINDS.has(device.kind) &&
    ORIGINS.has(device.origin) &&
    (device.sinkId === null || typeof device.sinkId === "string") &&
    (device.battery === null || typeof device.battery === "number") &&
    isNumberList(device.gains) &&
    isNumberList(device.altGains) &&
    (device.ab === "a" || device.ab === "b") &&
    typeof device.preamp === "number" &&
    typeof device.balance === "number" &&
    typeof device.volume === "number" &&
    typeof device.mono === "boolean" &&
    typeof device.loudness === "boolean" &&
    typeof device.crossfeed === "boolean" &&
    typeof device.limiter === "boolean"
  );
}

export function loadPersisted(): Persisted | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<Persisted>;
    const devices = Array.isArray(data.devices) ? data.devices.filter(isDevice) : [];
    if (devices.length === 0) return null;
    const activeId = devices.some((device) => device.id === data.activeId) ? (data.activeId as string) : devices[0].id;
    const source = SOURCES.has(data.source as SourceKind) ? (data.source as SourceKind) : "pulse";
    const customPresets = Array.isArray(data.customPresets)
      ? data.customPresets.filter(
          (preset): preset is CustomPreset =>
            !!preset &&
            typeof preset === "object" &&
            typeof (preset as CustomPreset).id === "string" &&
            typeof (preset as CustomPreset).name === "string" &&
            isNumberList((preset as CustomPreset).gains),
        )
      : [];
    return { devices, activeId, source, customPresets };
  } catch {
    return null;
  }
}

export function savePersisted(state: HaloState): void {
  if (typeof localStorage === "undefined") return;
  const data: Persisted = {
    devices: state.devices,
    activeId: state.activeId,
    source: state.source,
    customPresets: state.customPresets,
  };
  localStorage.setItem(KEY, JSON.stringify(data));
}
