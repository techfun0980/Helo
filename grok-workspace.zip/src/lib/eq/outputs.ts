export type OutputDevice = {
  deviceId: string;
  label: string;
  unnamed: boolean;
};

export function bluetoothAvailable(): boolean {
  return typeof navigator !== "undefined" && "bluetooth" in navigator;
}

export function outputSelectionAvailable(): boolean {
  return typeof HTMLMediaElement !== "undefined" && "setSinkId" in HTMLMediaElement.prototype;
}

export async function queryOutputs(): Promise<OutputDevice[]> {
  if (typeof navigator === "undefined" || !navigator.mediaDevices?.enumerateDevices) return [];
  const list = await navigator.mediaDevices.enumerateDevices();
  return list
    .filter((device) => device.kind === "audiooutput" && device.deviceId)
    .map((device, index) => {
      const label = device.label?.trim() ?? "";
      return {
        deviceId: device.deviceId,
        label: label || (device.deviceId === "default" ? "System default" : `Output ${index + 1}`),
        unnamed: label.length === 0,
      };
    });
}

export async function unlockOutputNames(): Promise<void> {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  stream.getTracks().forEach((track) => track.stop());
}

type GattCharacteristic = { readValue: () => Promise<DataView> };
type GattService = { getCharacteristic: (name: string) => Promise<GattCharacteristic> };
type GattServer = { getPrimaryService: (name: string) => Promise<GattService> };
type BleDevice = {
  id: string;
  name?: string;
  gatt?: { connect: () => Promise<GattServer> };
};
type BluetoothApi = {
  requestDevice: (options: { acceptAllDevices?: boolean; optionalServices?: string[] }) => Promise<BleDevice>;
};

function bluetoothApi(): BluetoothApi | null {
  const nav = navigator as Navigator & { bluetooth?: BluetoothApi };
  return nav.bluetooth ?? null;
}

export async function pairBluetooth(): Promise<{ id: string; name: string; battery: number | null }> {
  const api = bluetoothApi();
  if (!api) {
    throw new Error("Bluetooth scan isn't in this browser. Add earbuds from the system outputs list instead.");
  }
  const device = await api.requestDevice({
    acceptAllDevices: true,
    optionalServices: ["battery_service"],
  });
  let battery: number | null = null;
  try {
    const server = await device.gatt?.connect();
    if (server) {
      const service = await server.getPrimaryService("battery_service");
      const characteristic = await service.getCharacteristic("battery_level");
      const value = await characteristic.readValue();
      battery = value.getUint8(0);
    }
  } catch {
    battery = null;
  }
  return {
    id: device.id,
    name: device.name?.trim() || "Bluetooth device",
    battery,
  };
}
