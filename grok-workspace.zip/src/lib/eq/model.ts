export const BANDS = [
  { hz: 31, label: "31" },
  { hz: 62, label: "62" },
  { hz: 125, label: "125" },
  { hz: 250, label: "250" },
  { hz: 500, label: "500" },
  { hz: 1000, label: "1k" },
  { hz: 2000, label: "2k" },
  { hz: 4000, label: "4k" },
  { hz: 8000, label: "8k" },
  { hz: 16000, label: "16k" },
] as const;

export const BAND_COUNT = BANDS.length;

export type DeviceKind = "earbud" | "headphone" | "speaker" | "soundbar" | "car";
export type DeviceOrigin = "demo" | "system" | "bluetooth" | "manual";
export type SourceKind = "pulse" | "ambient" | "voice" | "noise" | "file" | "mic";
export type AbSlot = "a" | "b";
export type ToneGroup = "bass" | "mid" | "treble";

export type Preset = {
  id: string;
  name: string;
  hint: string;
  gains: number[];
};

export type CustomPreset = {
  id: string;
  name: string;
  gains: number[];
};

export type DeviceProfile = {
  id: string;
  name: string;
  kind: DeviceKind;
  origin: DeviceOrigin;
  sinkId: string | null;
  battery: number | null;
  gains: number[];
  altGains: number[];
  ab: AbSlot;
  preamp: number;
  balance: number;
  volume: number;
  mono: boolean;
  loudness: boolean;
  crossfeed: boolean;
  limiter: boolean;
};

const FLAT = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

export const PRESETS: Preset[] = [
  { id: "flat", name: "Flat", hint: "No color", gains: [...FLAT] },
  { id: "bass", name: "Bass", hint: "Low lift", gains: [7, 6, 4, 2, 0, 0, 0, 0, 0, 0] },
  { id: "treble", name: "Treble", hint: "Air and detail", gains: [0, 0, 0, 0, 0, 0, 1, 3, 5, 6] },
  { id: "vocal", name: "Vocal", hint: "Presence for voices", gains: [-2, -1, 0, 1, 3, 4, 4, 2, 0, -1] },
  { id: "podcast", name: "Podcast", hint: "Speech clarity", gains: [-4, -2, 0, 2, 4, 4, 2, 1, -1, -2] },
  { id: "earbud", name: "Earbud", hint: "Seal-friendly bass", gains: [3, 4, 3, 1, 0, 1, 2, 1, -1, -2] },
  { id: "speaker", name: "Speaker", hint: "Small-speaker fill", gains: [5, 4, 2, 1, 0, 0, 1, 2, 2, 1] },
  { id: "harman", name: "Harman", hint: "Headphone target", gains: [5, 4, 2, 1, 0, 0, 1, 2, 3, 2] },
  { id: "rock", name: "Rock", hint: "Scoop and bite", gains: [4, 3, 2, 0, -1, -1, 1, 3, 4, 4] },
  { id: "hiphop", name: "Hip-hop", hint: "Weight and snap", gains: [6, 5, 3, 1, -1, 0, 1, 2, 3, 3] },
  { id: "electronic", name: "Electronic", hint: "Sub and sparkle", gains: [6, 4, 1, 0, -1, 0, 1, 2, 4, 5] },
  { id: "jazz", name: "Jazz", hint: "Warm and open", gains: [3, 2, 1, 1, -1, -1, 0, 1, 2, 3] },
  { id: "classical", name: "Classical", hint: "Natural hall", gains: [3, 2, 1, 0, 0, 0, 0, 1, 2, 3] },
  { id: "acoustic", name: "Acoustic", hint: "String body", gains: [2, 2, 1, 0, 1, 2, 2, 1, 1, 1] },
  { id: "night", name: "Night", hint: "Softer highs", gains: [1, 2, 1, 0, 0, -1, -2, -4, -6, -7] },
  { id: "workout", name: "Workout", hint: "Energy curve", gains: [5, 4, 2, 0, -1, 0, 2, 3, 4, 3] },
  { id: "cinema", name: "Cinema", hint: "Soundbar weight", gains: [5, 4, 2, 0, -1, 0, 1, 2, 3, 2] },
  { id: "car", name: "Car", hint: "Road-noise cut", gains: [2, 3, 1, -1, -2, 1, 3, 3, 2, 1] },
];

export const SOURCES: { id: SourceKind; label: string }[] = [
  { id: "pulse", label: "Pulse" },
  { id: "ambient", label: "Ambient" },
  { id: "voice", label: "Voice" },
  { id: "noise", label: "Noise" },
  { id: "file", label: "File" },
  { id: "mic", label: "Mic" },
];

export const KIND_OPTIONS: { id: DeviceKind; label: string }[] = [
  { id: "earbud", label: "Earbuds" },
  { id: "headphone", label: "Headphones" },
  { id: "speaker", label: "Speaker" },
  { id: "soundbar", label: "Soundbar" },
  { id: "car", label: "Car" },
];

const GROUPS: Record<ToneGroup, number[]> = {
  bass: [0, 1, 2],
  mid: [3, 4, 5, 6],
  treble: [7, 8, 9],
};

export function clampDb(n: number): number {
  const rounded = Math.round(n * 10) / 10;
  return Math.max(-12, Math.min(12, rounded));
}

export function formatDb(n: number): string {
  const v = Math.round(n * 10) / 10;
  if (Math.abs(v) < 0.05) return "0.0";
  return `${v > 0 ? "+" : ""}${v.toFixed(1)}`;
}

export function formatBalance(n: number): string {
  if (Math.abs(n) < 0.03) return "Center";
  const pct = Math.round(Math.abs(n) * 100);
  return n < 0 ? `Left ${pct}` : `Right ${pct}`;
}

export function liveGains(device: DeviceProfile): number[] {
  return device.ab === "a" ? device.gains : device.altGains;
}

export function groupIndexes(group: ToneGroup): number[] {
  return GROUPS[group];
}

export function groupAverage(gains: number[], group: ToneGroup): number {
  const idx = GROUPS[group];
  const sum = idx.reduce((total, i) => total + (gains[i] ?? 0), 0);
  return sum / idx.length;
}

export function sameCurve(a: number[], b: number[]): boolean {
  if (a.length !== b.length) return false;
  return a.every((value, index) => Math.abs(value - (b[index] ?? 0)) < 0.05);
}

export function presetById(id: string): Preset | undefined {
  return PRESETS.find((preset) => preset.id === id);
}

export function defaultPresetFor(kind: DeviceKind): Preset {
  if (kind === "earbud") return presetById("earbud") ?? PRESETS[0];
  if (kind === "headphone") return presetById("harman") ?? PRESETS[0];
  if (kind === "soundbar") return presetById("cinema") ?? PRESETS[0];
  if (kind === "car") return presetById("car") ?? PRESETS[0];
  return presetById("speaker") ?? PRESETS[0];
}

export function identifyCurve(gains: number[], custom: CustomPreset[]): { id: string; name: string } {
  const built = PRESETS.find((preset) => sameCurve(preset.gains, gains));
  if (built) return { id: built.id, name: built.name };
  const saved = custom.find((preset) => sameCurve(preset.gains, gains));
  if (saved) return { id: saved.id, name: saved.name };
  return { id: "custom", name: "Custom" };
}

export function kindLabel(kind: DeviceKind): string {
  return KIND_OPTIONS.find((option) => option.id === kind)?.label ?? "Speaker";
}

export function originLabel(origin: DeviceOrigin): string {
  if (origin === "demo") return "Starter";
  if (origin === "system") return "System output";
  if (origin === "bluetooth") return "Bluetooth";
  return "Saved";
}

export function guessKind(name: string): DeviceKind {
  const n = name.toLowerCase();
  if (/airpod|buds|earbud|nothing ear|wf-|liberty|pixel bud|jabra elite/.test(n)) return "earbud";
  if (/car|vehicle|auto|honda|toyota|bmw|tesla|hyundai|kia|ford/.test(n)) return "car";
  if (/soundbar|sound bar|arc |beam|playbar|sonos arc/.test(n)) return "soundbar";
  if (/headphone|headset|wh-|qc\d|momentum|hd 6|bose/.test(n)) return "headphone";
  return "speaker";
}

function curve(gains: number[]): number[] {
  return gains.length === BAND_COUNT ? gains.map((value) => clampDb(value)) : [...FLAT];
}

export function createDevice(input: {
  id: string;
  name: string;
  kind: DeviceKind;
  origin: DeviceOrigin;
  sinkId?: string | null;
  battery?: number | null;
  presetId?: string;
}): DeviceProfile {
  const preset = input.presetId ? (presetById(input.presetId) ?? defaultPresetFor(input.kind)) : defaultPresetFor(input.kind);
  const gains = curve(preset.gains);
  return {
    id: input.id,
    name: input.name.slice(0, 40),
    kind: input.kind,
    origin: input.origin,
    sinkId: input.sinkId ?? null,
    battery: input.battery ?? null,
    gains,
    altGains: [...gains],
    ab: "a",
    preamp: 0,
    balance: 0,
    volume: 0.8,
    mono: false,
    loudness: false,
    crossfeed: input.kind === "earbud" || input.kind === "headphone",
    limiter: true,
  };
}

export function starterDevices(): DeviceProfile[] {
  return [
    createDevice({ id: "dev-commute", name: "Commute Buds", kind: "earbud", origin: "demo" }),
    createDevice({ id: "dev-desk", name: "Desk Speaker", kind: "speaker", origin: "demo" }),
    createDevice({ id: "dev-room", name: "Living Room Bar", kind: "soundbar", origin: "demo" }),
  ];
}

export function messageOf(error: unknown): string {
  if (error instanceof DOMException) {
    if (error.name === "NotAllowedError") return "Permission blocked. Allow access, then try again.";
    if (error.name === "NotFoundError") {
      return /cancel/i.test(error.message) ? "Cancelled." : "No matching device was found.";
    }
    if (error.name === "NotSupportedError") return "This browser can't do that here.";
    if (error.name === "SecurityError") return "The browser blocked device access.";
    if (error.name === "AbortError") return "Cancelled.";
    if (error.message) return error.message;
  }
  if (error instanceof Error && error.message) return error.message;
  return "Something went wrong.";
}
