import { useEffect, useRef, useState, type InputHTMLAttributes } from "react";
import { Pause, Play } from "lucide-react";
import { EqCurve } from "@/components/equalizer/curve";
import { DevicePanel } from "@/components/equalizer/devices";
import { getEngine } from "@/lib/eq/engine";
import {
  BANDS,
  formatBalance,
  formatDb,
  groupAverage,
  identifyCurve,
  kindLabel,
  liveGains,
  messageOf,
  PRESETS,
  SOURCES,
  type SourceKind,
  type ToneGroup,
} from "@/lib/eq/model";
import { loadPersisted, savePersisted, useHalo } from "@/lib/eq/store";

export function HaloApp() {
  const devices = useHalo((state) => state.devices);
  const activeId = useHalo((state) => state.activeId);
  const source = useHalo((state) => state.source);
  const customPresets = useHalo((state) => state.customPresets);
  const bypass = useHalo((state) => state.bypass);
  const hydrated = useHalo((state) => state.hydrated);
  const setSource = useHalo((state) => state.setSource);
  const setBand = useHalo((state) => state.setBand);
  const setGroupAverage = useHalo((state) => state.setGroupAverage);
  const setAb = useHalo((state) => state.setAb);
  const copyAlt = useHalo((state) => state.copyAlt);
  const resetLive = useHalo((state) => state.resetLive);
  const updateActive = useHalo((state) => state.updateActive);
  const toggleBypass = useHalo((state) => state.toggleBypass);
  const applyPreset = useHalo((state) => state.applyPreset);
  const addCustomPreset = useHalo((state) => state.addCustomPreset);
  const removeCustomPreset = useHalo((state) => state.removeCustomPreset);

  const device = devices.find((item) => item.id === activeId) ?? devices[0] ?? null;
  const gains = device ? liveGains(device) : [];
  const preset = device ? identifyCurve(gains, customPresets) : { id: "flat", name: "Flat" };

  const [playing, setPlaying] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [routeNote, setRouteNote] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileToken, setFileToken] = useState(0);
  const [presetName, setPresetName] = useState("");
  const [presetNote, setPresetNote] = useState<string | null>(null);
  const fileRef = useRef<AudioBuffer | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = loadPersisted();
    if (saved) useHalo.getState().hydrate(saved);
    useHalo.getState().markHydrated();
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    savePersisted(useHalo.getState());
    return useHalo.subscribe((state) => savePersisted(state));
  }, [hydrated]);

  useEffect(() => {
    if (!device) return;
    getEngine().configure({
      gains,
      preamp: device.preamp,
      volume: device.volume,
      balance: device.balance,
      mono: device.mono,
      loudness: device.loudness,
      crossfeed: device.crossfeed,
      limiter: device.limiter,
      bypass,
    });
  }, [device, gains, bypass]);

  useEffect(() => {
    if (!playing) {
      getEngine().stop();
      return;
    }
    let cancel = false;
    void getEngine()
      .play(source, fileRef.current)
      .catch((err: unknown) => {
        if (cancel) return;
        setError(messageOf(err));
        setPlaying(false);
      });
    return () => {
      cancel = true;
    };
  }, [playing, source, fileToken]);

  useEffect(() => {
    if (!playing) return;
    let cancel = false;
    void getEngine()
      .route(device?.sinkId ?? null)
      .then((result) => {
        if (!cancel) setRouteNote(result.ok ? null : (result.reason ?? null));
      });
    return () => {
      cancel = true;
    };
  }, [playing, device?.sinkId]);

  const onFile = async (file: File) => {
    setError(null);
    try {
      const ctx = getEngine().ensureContext();
      const decoded = await ctx.decodeAudioData(await file.arrayBuffer());
      fileRef.current = decoded;
      setFileName(file.name);
      setSource("file");
      setFileToken((token) => token + 1);
      setPlaying(true);
    } catch (err) {
      setError(messageOf(err) || "That file couldn't be read as audio.");
    }
  };

  const togglePlay = () => {
    setError(null);
    if (playing) {
      setPlaying(false);
      return;
    }
    if (source === "file" && !fileRef.current) {
      setError("Choose an audio file first.");
      fileInputRef.current?.click();
      return;
    }
    setPlaying(true);
  };

  const savePreset = () => {
    const ok = addCustomPreset(presetName);
    if (!ok) {
      setPresetNote(presetName.trim() ? "Delete a saved preset before adding another." : "Name the preset first.");
      return;
    }
    setPresetName("");
    setPresetNote(null);
  };

  const status = error
    ? error
    : routeNote
      ? routeNote
      : device
        ? `${labelForSource(source)} · ${device.name} · ${device.sinkId ? "selected output" : "system default"}`
        : "Add a device to start.";

  return (
    <main className="mx-auto min-h-screen max-w-6xl px-4 py-4 md:px-6 md:py-6">
      <header className="mb-4 flex min-w-0 items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-primary text-primary-fg">
            <WaveMark />
          </span>
          <div className="min-w-0">
            <h1 className="text-xl font-semibold leading-none">Halo EQ</h1>
            <p className="mt-1 truncate text-sm text-muted">Earbuds, speakers, and every device you switch</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Meters playing={playing} />
          <ClipLamp playing={playing} />
        </div>
      </header>

      <div className="grid min-w-0 items-start gap-4 lg:grid-cols-4">
        <div className="min-w-0 lg:col-span-1">
          <DevicePanel />
        </div>
        <section className="grid min-w-0 gap-4 lg:col-span-3">
          <div className="min-w-0 rounded-xl border border-border bg-surface p-3 md:p-4">
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={togglePlay}
                aria-label={playing ? "Pause" : "Play"}
                className="grid size-14 shrink-0 place-items-center rounded-full bg-primary text-primary-fg"
              >
                {playing ? <Pause className="size-6" aria-hidden /> : <Play className="size-6 translate-x-0.5" aria-hidden />}
              </button>
              <button
                type="button"
                aria-pressed={bypass}
                onClick={toggleBypass}
                className={`h-11 shrink-0 rounded-lg px-4 text-sm font-semibold ${bypass ? "bg-primary text-primary-fg" : "border border-border bg-bg"}`}
              >
                {bypass ? "Bypass on" : "Bypass"}
              </button>
              <label className="grid w-full gap-1 text-xs text-muted sm:w-auto sm:min-w-48 sm:flex-1">
                <span className="flex justify-between">
                  Volume
                  <span className="font-mono text-fg">{device ? Math.round(device.volume * 100) : 0}</span>
                </span>
                <Slider
                  min={0}
                  max={1}
                  step={0.01}
                  value={device?.volume ?? 0.8}
                  aria-label="Volume"
                  onChange={(event) => updateActive({ volume: Number(event.target.value) })}
                />
              </label>
            </div>
            <div className="mt-3 flex min-w-0 gap-2 overflow-x-auto">
              {SOURCES.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={source === item.id}
                  onClick={() => {
                    setError(null);
                    if (item.id === "file") {
                      setSource("file");
                      if (!fileRef.current) fileInputRef.current?.click();
                      return;
                    }
                    setSource(item.id);
                  }}
                  className={`h-11 shrink-0 rounded-full px-4 text-sm ${source === item.id ? "bg-primary font-semibold text-primary-fg" : "border border-border bg-bg"}`}
                >
                  {item.label}
                </button>
              ))}
              <input
                ref={fileInputRef}
                type="file"
                accept="audio/*,.mp3,.wav,.ogg,.m4a,.aac,.flac"
                className="sr-only"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) void onFile(file);
                  event.target.value = "";
                }}
              />
            </div>
            <p role={error ? "alert" : "status"} className={`mt-3 text-sm ${error || routeNote ? "text-clip" : "text-muted"}`}>
              {status}
              {fileName && source === "file" ? ` · ${fileName}` : ""}
            </p>
            {source === "mic" ? <p className="mt-1 text-xs text-muted">Wear the earbuds so the microphone doesn't howl.</p> : null}
            {source === "noise" ? <p className="mt-1 text-xs text-muted">Pink noise makes every band easy to hear.</p> : null}
          </div>

          <div className={`rounded-xl border border-border bg-surface p-3 md:p-4 ${bypass ? "opacity-80" : ""}`}>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-sm font-semibold">Curve</h2>
                <p className="text-xs text-muted">
                  {preset.name}
                  {device ? ` · ${kindLabel(device.kind)}` : ""} · drag a point or a slider
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex overflow-hidden rounded-lg border border-border">
                  <button
                    type="button"
                    aria-pressed={device?.ab === "a"}
                    onClick={() => setAb("a")}
                    className={`h-11 px-4 text-sm font-semibold ${device?.ab === "a" ? "bg-primary text-primary-fg" : "bg-bg"}`}
                  >
                    A
                  </button>
                  <button
                    type="button"
                    aria-pressed={device?.ab === "b"}
                    onClick={() => setAb("b")}
                    className={`h-11 px-4 text-sm font-semibold ${device?.ab === "b" ? "bg-primary text-primary-fg" : "bg-bg"}`}
                  >
                    B
                  </button>
                </div>
                <button type="button" onClick={copyAlt} className="h-11 rounded-lg border border-border bg-bg px-3 text-sm">
                  Copy to {device?.ab === "a" ? "B" : "A"}
                </button>
                <button type="button" onClick={resetLive} className="h-11 rounded-lg border border-border bg-bg px-3 text-sm">
                  Reset
                </button>
              </div>
            </div>
            <div className="overflow-hidden rounded-lg border border-border bg-bg">
              <EqCurve gains={gains} playing={playing} bypass={bypass} onChange={setBand} />
            </div>
            {bypass ? <p className="mt-2 text-xs text-primary">Bypass is on. You are hearing the signal without EQ.</p> : null}
          </div>

          <div className="min-w-0">
            <h2 className="mb-2 text-sm font-semibold">Presets</h2>
            <div className="flex min-w-0 gap-2 overflow-x-auto pb-1">
              {PRESETS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  title={item.hint}
                  aria-pressed={preset.id === item.id}
                  onClick={() => applyPreset(item.id)}
                  className={`h-11 shrink-0 rounded-full px-4 text-sm ${preset.id === item.id ? "bg-primary font-semibold text-primary-fg" : "border border-border bg-surface"}`}
                >
                  {item.name}
                </button>
              ))}
              {customPresets.map((item) => (
                <span key={item.id} className="flex shrink-0 overflow-hidden rounded-full border border-border">
                  <button
                    type="button"
                    aria-pressed={preset.id === item.id}
                    onClick={() => applyPreset(item.id)}
                    className={`h-11 px-4 text-sm ${preset.id === item.id ? "bg-primary font-semibold text-primary-fg" : "bg-surface"}`}
                  >
                    {item.name}
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete ${item.name}`}
                    onClick={() => removeCustomPreset(item.id)}
                    className="h-11 bg-surface px-3 text-sm text-muted"
                  >
                    Del
                  </button>
                </span>
              ))}
            </div>
            <form
              className="mt-2 flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                savePreset();
              }}
            >
              <input
                value={presetName}
                onChange={(event) => setPresetName(event.target.value)}
                placeholder="Name this curve"
                aria-label="Preset name"
                maxLength={24}
                className="h-11 min-w-0 flex-1 rounded-lg border border-border bg-surface px-3 text-sm"
              />
              <button type="submit" className="h-11 shrink-0 rounded-lg border border-border bg-surface px-4 text-sm font-semibold">
                Save preset
              </button>
            </form>
            {presetNote ? <p className="mt-2 text-xs text-clip">{presetNote}</p> : null}
          </div>

          <div className="rounded-xl border border-border bg-surface p-3 md:p-4">
            <div className="mb-2 flex items-baseline justify-between gap-2">
              <h2 className="text-sm font-semibold">Bands</h2>
              <p className="text-xs text-muted">Tap a frequency to hear it</p>
            </div>
            <div className="grid gap-1">
              {BANDS.map((band, index) => (
                <div key={band.hz} className="grid grid-cols-12 items-center gap-2">
                  <button
                    type="button"
                    onClick={() => getEngine().audition(band.hz)}
                    className="col-span-2 h-11 text-left font-mono text-xs text-muted"
                  >
                    {band.label}
                  </button>
                  <Slider
                    className="col-span-8"
                    min={-12}
                    max={12}
                    step={0.1}
                    value={gains[index] ?? 0}
                    aria-label={`${band.label} hertz`}
                    onChange={(event) => setBand(index, Number(event.target.value))}
                    onDoubleClick={() => setBand(index, 0)}
                  />
                  <span className="col-span-2 text-right font-mono text-xs">{formatDb(gains[index] ?? 0)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <section className="rounded-xl border border-border bg-surface p-3 md:p-4">
              <h2 className="mb-2 text-sm font-semibold">Tone</h2>
              <div className="grid gap-2">
                <ToneSlider label="Bass" group="bass" gains={gains} onChange={setGroupAverage} />
                <ToneSlider label="Mid" group="mid" gains={gains} onChange={setGroupAverage} />
                <ToneSlider label="Treble" group="treble" gains={gains} onChange={setGroupAverage} />
                <label className="grid gap-1 text-xs text-muted">
                  <span className="flex justify-between">
                    Preamp
                    <span className="font-mono text-fg">{formatDb(device?.preamp ?? 0)}</span>
                  </span>
                  <Slider
                    min={-12}
                    max={12}
                    step={0.1}
                    value={device?.preamp ?? 0}
                    aria-label="Preamp"
                    onChange={(event) => updateActive({ preamp: Number(event.target.value) })}
                    onDoubleClick={() => updateActive({ preamp: 0 })}
                  />
                </label>
              </div>
            </section>
            <section className="rounded-xl border border-border bg-surface p-3 md:p-4">
              <h2 className="mb-2 text-sm font-semibold">Output</h2>
              <label className="mb-3 grid gap-1 text-xs text-muted">
                <span className="flex justify-between">
                  Balance
                  <span className="font-mono text-fg">{formatBalance(device?.balance ?? 0)}</span>
                </span>
                <Slider
                  min={-1}
                  max={1}
                  step={0.01}
                  value={device?.balance ?? 0}
                  aria-label="Balance"
                  onChange={(event) => updateActive({ balance: Number(event.target.value) })}
                  onDoubleClick={() => updateActive({ balance: 0 })}
                />
              </label>
              <div className="grid grid-cols-2 gap-2">
                <Toggle label="Mono" on={device?.mono ?? false} onClick={() => updateActive({ mono: !device?.mono })} />
                <Toggle label="Loudness" on={device?.loudness ?? false} onClick={() => updateActive({ loudness: !device?.loudness })} />
                <Toggle label="Crossfeed" on={device?.crossfeed ?? false} onClick={() => updateActive({ crossfeed: !device?.crossfeed })} />
                <Toggle label="Limiter" on={device?.limiter ?? false} onClick={() => updateActive({ limiter: !device?.limiter })} />
              </div>
              <p className="mt-3 text-xs text-muted">Crossfeed is for earbuds. Loudness lifts lows and highs when the volume is down.</p>
            </section>
          </div>
        </section>
      </div>
    </main>
  );
}

function Slider(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input type="range" suppressHydrationWarning {...props} />;
}

function labelForSource(source: SourceKind): string {
  return SOURCES.find((item) => item.id === source)?.label ?? "Pulse";
}

function ToneSlider({
  label,
  group,
  gains,
  onChange,
}: {
  label: string;
  group: ToneGroup;
  gains: number[];
  onChange: (group: ToneGroup, value: number) => void;
}) {
  const average = gains.length ? groupAverage(gains, group) : 0;
  return (
    <label className="grid gap-1 text-xs text-muted">
      <span className="flex justify-between">
        {label}
        <span className="font-mono text-fg">{formatDb(average)}</span>
      </span>
      <Slider
        min={-12}
        max={12}
        step={0.1}
        value={Math.round(average * 10) / 10}
        aria-label={label}
        onChange={(event) => onChange(group, Number(event.target.value))}
        onDoubleClick={() => onChange(group, 0)}
      />
    </label>
  );
}

function Toggle({ label, on, onClick }: { label: string; on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={`h-11 rounded-lg text-sm font-semibold ${on ? "bg-primary text-primary-fg" : "border border-border bg-bg"}`}
    >
      {label}
      <span className="sr-only">{on ? " on" : " off"}</span>
    </button>
  );
}

function WaveMark() {
  return (
    <svg viewBox="0 0 24 24" className="size-6" aria-hidden>
      <path
        d="M2 15c2-6 4 3 6 0s4 5 6 0 4 4 6 0"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

function Meters({ playing }: { playing: boolean }) {
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const paint = (value: number) => `scaleX(${Math.min(1, value * 2.8)})`;
    if (!playing) {
      if (leftRef.current) leftRef.current.style.transform = "scaleX(0)";
      if (rightRef.current) rightRef.current.style.transform = "scaleX(0)";
      return;
    }
    let frame = 0;
    const tick = () => {
      const levels = getEngine().getLevels();
      if (leftRef.current) leftRef.current.style.transform = paint(levels.l);
      if (rightRef.current) rightRef.current.style.transform = paint(levels.r);
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing]);
  return (
    <div className="flex w-16 flex-col gap-1 sm:w-24" aria-hidden>
      <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
        <div ref={leftRef} className="h-full w-full origin-left bg-primary" style={{ transform: "scaleX(0)" }} />
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
        <div ref={rightRef} className="h-full w-full origin-left bg-primary" style={{ transform: "scaleX(0)" }} />
      </div>
    </div>
  );
}

function ClipLamp({ playing }: { playing: boolean }) {
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    let hold = 0;
    let frame = 0;
    if (!playing) {
      if (ref.current) ref.current.dataset.hot = "0";
      return;
    }
    const tick = () => {
      const peak = getEngine().getLevels().peak;
      if (peak > 0.92) hold = 14;
      if (ref.current) ref.current.dataset.hot = hold > 0 ? "1" : "0";
      if (hold > 0) hold -= 1;
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing]);
  return (
    <span className="flex items-center gap-2 text-xs text-muted">
      <span ref={ref} data-hot="0" className="size-2.5 rounded-full bg-border data-[hot=1]:bg-clip" />
      Clip
    </span>
  );
}
