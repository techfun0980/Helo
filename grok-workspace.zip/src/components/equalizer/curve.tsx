import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { BANDS } from "@/lib/eq/model";
import { getEngine } from "@/lib/eq/engine";

const PAD_X = 18;
const PAD_Y = 18;
const AXIS = [12, 6, 0, -6, -12];
const FREQ_LABELS = new Set([31, 125, 500, 2000, 8000, 16000]);

type Props = {
  gains: number[];
  playing: boolean;
  bypass: boolean;
  onChange: (index: number, value: number) => void;
};

function xOf(freq: number, width: number): number {
  const min = Math.log(20);
  const max = Math.log(20000);
  return PAD_X + ((Math.log(freq) - min) / (max - min)) * (width - PAD_X * 2);
}

function yOf(db: number, height: number): number {
  const clamped = Math.max(-12, Math.min(12, db));
  return PAD_Y + ((12 - clamped) / 24) * (height - PAD_Y * 2);
}

function dbOf(y: number, height: number): number {
  const span = height - PAD_Y * 2;
  const t = span <= 0 ? 0 : (y - PAD_Y) / span;
  return Math.max(-12, Math.min(12, 12 - t * 24));
}

function curvePath(gains: number[], width: number, height: number): string {
  const points = BANDS.map((band, index) => ({
    x: xOf(band.hz, width),
    y: yOf(gains[index] ?? 0, height),
  }));
  const first = points[0];
  const last = points[points.length - 1];
  if (!first || !last) return "";
  let d = `M 0 ${first.y} L ${first.x} ${first.y}`;
  for (let i = 0; i < points.length - 1; i += 1) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    if (!p0 || !p1 || !p2 || !p3) continue;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2.x} ${p2.y}`;
  }
  d += ` L ${width} ${last.y}`;
  return d;
}

function spectrumPath(data: ArrayLike<number>, sampleRate: number, width: number, height: number): string {
  const min = Math.log(20);
  const max = Math.log(20000);
  const nyquist = sampleRate / 2;
  const bottom = height - 8;
  let d = `M 0 ${bottom}`;
  const step = 6;
  for (let x = 0; x <= width; x += step) {
    const freq = Math.exp(min + (x / Math.max(1, width)) * (max - min));
    const bin = Math.min(data.length - 1, Math.max(0, Math.round((freq / nyquist) * data.length)));
    const value = (data[bin] ?? 0) / 255;
    const y = bottom - value * (height - PAD_Y * 2);
    d += ` L ${x} ${y}`;
  }
  d += ` L ${width} ${bottom} Z`;
  return d;
}

export function EqCurve({ gains, playing, bypass, onChange }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const specRef = useRef<SVGPathElement>(null);
  const gainsRef = useRef(gains);
  const dragRef = useRef<number | null>(null);
  gainsRef.current = gains;
  const [size, setSize] = useState({ w: 0, h: 0 });

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => {
      const rect = el.getBoundingClientRect();
      setSize({ w: Math.max(1, rect.width), h: Math.max(1, rect.height) });
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const spec = specRef.current;
    if (!playing) {
      spec?.setAttribute("d", "");
      return;
    }
    const smooth = { values: null as Float32Array | null };
    let frame = 0;
    const loop = () => {
      const engine = getEngine();
      const data = engine.getSpectrum();
      if (spec && data && size.w > 0) {
        if (!smooth.values || smooth.values.length !== data.length) smooth.values = new Float32Array(data.length);
        const values = smooth.values;
        for (let i = 0; i < data.length; i += 1) values[i] = values[i] * 0.72 + (data[i] ?? 0) * 0.28;
        spec.setAttribute("d", spectrumPath(values, engine.sampleRate, size.w, size.h));
      }
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [playing, size.w, size.h]);

  const pointFromEvent = (event: ReactPointerEvent<SVGSVGElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    return {
      x: ((event.clientX - rect.left) / Math.max(1, rect.width)) * size.w,
      y: ((event.clientY - rect.top) / Math.max(1, rect.height)) * size.h,
    };
  };

  const nearest = (x: number, y: number) => {
    let best = -1;
    let bestDistance = 42;
    BANDS.forEach((band, index) => {
      const distance = Math.hypot(xOf(band.hz, size.w) - x, yOf(gainsRef.current[index] ?? 0, size.h) - y);
      if (distance < bestDistance) {
        bestDistance = distance;
        best = index;
      }
    });
    return best;
  };

  const onPointerDown = (event: ReactPointerEvent<SVGSVGElement>) => {
    if (size.w <= 0) return;
    const point = pointFromEvent(event);
    const index = nearest(point.x, point.y);
    if (index < 0) return;
    dragRef.current = index;
    event.currentTarget.setPointerCapture(event.pointerId);
    onChange(index, dbOf(point.y, size.h));
  };

  const onPointerMove = (event: ReactPointerEvent<SVGSVGElement>) => {
    const index = dragRef.current;
    if (index === null) return;
    const point = pointFromEvent(event);
    onChange(index, dbOf(point.y, size.h));
  };

  const endDrag = () => {
    dragRef.current = null;
  };

  const path = size.w > 0 ? curvePath(gains, size.w, size.h) : "";
  const zero = size.h > 0 ? yOf(0, size.h) : 0;
  const fill = path ? `${path} L ${size.w} ${zero} L 0 ${zero} Z` : "";

  return (
    <div ref={wrapRef} className="relative h-56 w-full md:h-64">
      {size.w > 0 ? (
        <svg
          className="h-full w-full touch-none"
          viewBox={`0 0 ${size.w} ${size.h}`}
          role="application"
          aria-label="Equalizer curve. Drag a point to change that band. Band sliders below do the same."
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
        >
          {AXIS.map((db) => (
            <line
              key={db}
              x1={0}
              x2={size.w}
              y1={yOf(db, size.h)}
              y2={yOf(db, size.h)}
              className={db === 0 ? "stroke-border" : "stroke-border/50"}
              strokeWidth={1}
            />
          ))}
          <path ref={specRef} className="fill-primary/15" />
          <path d={fill} className={bypass ? "fill-muted/20" : "fill-primary/25"} />
          <path
            d={path}
            className={bypass ? "stroke-muted" : "stroke-primary"}
            fill="none"
            strokeWidth={2.5}
            strokeLinejoin="round"
            strokeLinecap="round"
          />
          {BANDS.map((band, index) => {
            const cx = xOf(band.hz, size.w);
            const cy = yOf(gains[index] ?? 0, size.h);
            return (
              <g key={band.hz}>
                <circle cx={cx} cy={cy} r={16} className="fill-transparent" />
                <circle cx={cx} cy={cy} r={5} className={bypass ? "fill-muted stroke-bg" : "fill-primary stroke-bg"} strokeWidth={2} />
              </g>
            );
          })}
        </svg>
      ) : null}
      <div className="pointer-events-none absolute top-2 bottom-6 left-2 flex flex-col justify-between font-mono text-xs text-muted">
        <span>+12</span>
        <span>0</span>
        <span>-12</span>
      </div>
      <div className="pointer-events-none absolute inset-x-0 bottom-1">
        {size.w > 0
          ? BANDS.filter((band) => FREQ_LABELS.has(band.hz)).map((band) => (
              <span
                key={band.hz}
                className="absolute -translate-x-1/2 font-mono text-xs text-muted"
                style={{ left: `${(xOf(band.hz, size.w) / size.w) * 100}%` }}
              >
                {band.label}
              </span>
            ))
          : null}
      </div>
    </div>
  );
}
