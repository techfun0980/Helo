import { useEffect, useState } from "react";
import { Bluetooth, Car, Copy, Headphones, Plus, Radio, Speaker, Trash2, X } from "lucide-react";
import {
  createDevice,
  guessKind,
  identifyCurve,
  kindLabel,
  KIND_OPTIONS,
  liveGains,
  messageOf,
  originLabel,
  type DeviceKind,
  type DeviceProfile,
} from "@/lib/eq/model";
import { bluetoothAvailable, pairBluetooth, queryOutputs, unlockOutputNames, type OutputDevice } from "@/lib/eq/outputs";
import { useHalo } from "@/lib/eq/store";

function KindIcon({ kind }: { kind: DeviceKind }) {
  const className = "size-5";
  if (kind === "earbud" || kind === "headphone") return <Headphones className={className} aria-hidden />;
  if (kind === "soundbar") return <Radio className={className} aria-hidden />;
  if (kind === "car") return <Car className={className} aria-hidden />;
  return <Speaker className={className} aria-hidden />;
}

export function DevicePanel() {
  const devices = useHalo((state) => state.devices);
  const activeId = useHalo((state) => state.activeId);
  const customPresets = useHalo((state) => state.customPresets);
  const setActive = useHalo((state) => state.setActive);
  const updateActive = useHalo((state) => state.updateActive);
  const upsertDevice = useHalo((state) => state.upsertDevice);
  const removeDevice = useHalo((state) => state.removeDevice);
  const duplicateActive = useHalo((state) => state.duplicateActive);
  const [open, setOpen] = useState(false);

  return (
    <aside className="min-w-0">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold">Devices</h2>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-3 text-sm font-semibold text-primary-fg"
        >
          <Plus className="size-4" aria-hidden />
          Add
        </button>
      </div>
      <div className="flex min-w-0 gap-3 overflow-x-auto pb-1 lg:flex-col lg:overflow-visible">
        {devices.map((device) => (
          <DeviceCard
            key={device.id}
            device={device}
            active={device.id === activeId}
            presetName={identifyCurve(liveGains(device), customPresets).name}
            canDelete={devices.length > 1}
            onSelect={() => setActive(device.id)}
            onRename={(name) => updateActive({ name })}
            onKind={(kind) => updateActive({ kind })}
            onDuplicate={duplicateActive}
            onDelete={() => removeDevice(device.id)}
          />
        ))}
      </div>
      <p className="mt-3 text-xs text-muted">One device plays at a time. Each one keeps its own curve, volume, and tuning.</p>
      {open ? <AddDeviceDialog onClose={() => setOpen(false)} onAdd={upsertDevice} /> : null}
    </aside>
  );
}

function DeviceCard({
  device,
  active,
  presetName,
  canDelete,
  onSelect,
  onRename,
  onKind,
  onDuplicate,
  onDelete,
}: {
  device: DeviceProfile;
  active: boolean;
  presetName: string;
  canDelete: boolean;
  onSelect: () => void;
  onRename: (name: string) => void;
  onKind: (kind: DeviceKind) => void;
  onDuplicate: () => void;
  onDelete: () => void;
}) {
  return (
    <article
      className={`min-w-64 rounded-xl border p-3 lg:min-w-0 ${active ? "border-primary bg-surface-2" : "border-border bg-surface"}`}
    >
      <button type="button" onClick={onSelect} aria-pressed={active} className="flex w-full items-center gap-3 text-left">
        <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-bg text-primary">
          <KindIcon kind={device.kind} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2">
            <span className="truncate font-semibold">{device.name}</span>
            {active ? <span className="size-2 shrink-0 rounded-full bg-primary" aria-hidden /> : null}
          </span>
          <span className="mt-0.5 block truncate text-xs text-muted">
            {kindLabel(device.kind)} · {presetName} · {originLabel(device.origin)}
            {device.battery !== null ? ` · ${device.battery}%` : ""}
          </span>
        </span>
      </button>
      {active ? (
        <div className="mt-3 grid gap-2">
          <label className="grid gap-1 text-xs text-muted">
            Name
            <input
              value={device.name}
              onChange={(event) => onRename(event.target.value)}
              className="h-11 rounded-lg border border-border bg-bg px-3 text-sm text-fg"
              maxLength={40}
            />
          </label>
          <label className="grid gap-1 text-xs text-muted">
            Type
            <select
              value={device.kind}
              onChange={(event) => onKind(event.target.value as DeviceKind)}
              className="h-11 rounded-lg border border-border bg-bg px-3 text-sm text-fg"
            >
              {KIND_OPTIONS.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onDuplicate}
              className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg border border-border bg-bg text-sm"
            >
              <Copy className="size-4" aria-hidden />
              Duplicate
            </button>
            <button
              type="button"
              onClick={onDelete}
              disabled={!canDelete}
              className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg border border-border bg-bg text-sm"
            >
              <Trash2 className="size-4" aria-hidden />
              Remove
            </button>
          </div>
        </div>
      ) : null}
    </article>
  );
}

function AddDeviceDialog({ onClose, onAdd }: { onClose: () => void; onAdd: (device: DeviceProfile) => void }) {
  const [outputs, setOutputs] = useState<OutputDevice[]>([]);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const [manualName, setManualName] = useState("");
  const [manualKind, setManualKind] = useState<DeviceKind>("earbud");

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    let cancel = false;
    void queryOutputs()
      .then((list) => {
        if (!cancel) setOutputs(list);
      })
      .catch((error: unknown) => {
        if (!cancel) setNote(messageOf(error));
      });
    return () => {
      cancel = true;
    };
  }, []);

  const refresh = async () => {
    setOutputs(await queryOutputs());
  };

  const addOutput = (output: OutputDevice) => {
    onAdd(
      createDevice({
        id: `out-${output.deviceId}`,
        name: output.label,
        kind: guessKind(output.label),
        origin: "system",
        sinkId: output.deviceId,
      }),
    );
    onClose();
  };

  const scan = async () => {
    setBusy(true);
    setNote(null);
    try {
      const found = await pairBluetooth();
      onAdd(
        createDevice({
          id: `bt-${found.id}`,
          name: found.name,
          kind: guessKind(found.name),
          origin: "bluetooth",
          battery: found.battery,
        }),
      );
      onClose();
    } catch (error) {
      setNote(messageOf(error));
    } finally {
      setBusy(false);
    }
  };

  const unlock = async () => {
    setBusy(true);
    setNote(null);
    try {
      await unlockOutputNames();
      await refresh();
    } catch (error) {
      setNote(messageOf(error));
    } finally {
      setBusy(false);
    }
  };

  const addManual = () => {
    const name = manualName.trim();
    if (!name) {
      setNote("Name the device first.");
      return;
    }
    onAdd(
      createDevice({
        id: `manual-${crypto.randomUUID()}`,
        name,
        kind: manualKind,
        origin: "manual",
      }),
    );
    onClose();
  };

  const unnamed = outputs.some((output) => output.unnamed);

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-bg/70 sm:items-center sm:p-6" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="add-device-title"
        className="max-h-full w-full overflow-y-auto border border-border bg-surface p-4 sm:max-w-md sm:rounded-xl"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mb-3 flex items-start justify-between gap-3">
          <div>
            <h3 id="add-device-title" className="text-lg font-semibold">
              Add a device
            </h3>
            <p className="mt-1 text-sm text-muted">
              Pick an output already connected to this phone or computer, scan Bluetooth, or save a manual profile.
            </p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="grid size-11 place-items-center rounded-lg border border-border">
            <X className="size-4" aria-hidden />
          </button>
        </div>

        <h4 className="mb-2 text-sm font-semibold">System outputs</h4>
        {outputs.length === 0 ? (
          <p className="mb-3 text-sm text-muted">No outputs reported yet. Connect earbuds or a speaker, then refresh.</p>
        ) : (
          <div className="mb-3 grid gap-2">
            {outputs.map((output) => (
              <button
                key={output.deviceId}
                type="button"
                onClick={() => addOutput(output)}
                className="h-11 truncate rounded-lg border border-border bg-bg px-3 text-left text-sm"
              >
                {output.label}
              </button>
            ))}
          </div>
        )}
        <div className="mb-4 flex flex-wrap gap-2">
          <button type="button" onClick={() => void refresh()} className="h-11 rounded-lg border border-border px-3 text-sm">
            Refresh
          </button>
          {unnamed ? (
            <button type="button" disabled={busy} onClick={() => void unlock()} className="h-11 rounded-lg border border-border px-3 text-sm">
              Show names
            </button>
          ) : null}
        </div>

        <h4 className="mb-2 text-sm font-semibold">Bluetooth</h4>
        <button
          type="button"
          disabled={busy || !bluetoothAvailable()}
          onClick={() => void scan()}
          className="mb-2 inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-border bg-bg text-sm"
        >
          <Bluetooth className="size-4" aria-hidden />
          {bluetoothAvailable() ? "Scan nearby Bluetooth" : "Bluetooth scan unavailable"}
        </button>
        <p className="mb-4 text-xs text-muted">
          A scan can save the device and its battery when the device shares it. Sound still plays through the system output you select.
        </p>

        <h4 className="mb-2 text-sm font-semibold">Manual profile</h4>
        <div className="grid gap-2">
          <input
            value={manualName}
            onChange={(event) => setManualName(event.target.value)}
            placeholder="Kitchen speaker"
            aria-label="Device name"
            className="h-11 rounded-lg border border-border bg-bg px-3 text-sm"
            maxLength={40}
          />
          <select
            value={manualKind}
            aria-label="Device type"
            onChange={(event) => setManualKind(event.target.value as DeviceKind)}
            className="h-11 rounded-lg border border-border bg-bg px-3 text-sm"
          >
            {KIND_OPTIONS.map((option) => (
              <option key={option.id} value={option.id}>
                {option.label}
              </option>
            ))}
          </select>
          <button type="button" onClick={addManual} className="h-11 rounded-lg bg-primary text-sm font-semibold text-primary-fg">
            Save profile
          </button>
        </div>
        {note ? (
          <p role="alert" className="mt-3 text-sm text-clip">
            {note}
          </p>
        ) : null}
      </div>
    </div>
  );
}
